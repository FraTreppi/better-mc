# MC Code Project — demo offline

Apri questa cartella in VS Code o nel tuo editor. Tutti i contenuti sono fittizi.

- retrieve/demo/BU-demo contiene email, template, CloudPage, query e Journey.
- docs/demo/BU-demo contiene inventario, dipendenze e diagramma Journey.
- Modifica HTML e SQL, poi confronta i file con Git. Per iniziare lo storico della demo ZIP scegli Inizializza repository in Source Control oppure git init.
- Per usare inventario e documentazione installa Node.js 24.15+; non servono npm install o credenziali.
- I task sono in Terminale → Esegui attività: usa demo/BU-demo per la BU.

La demo blocca collegamento, pull, invio e attivazione Salesforce. Per un progetto reale scarica lo strumento locale e usa init, mantenendo questa demo separata.

[Guida e strumento locale](https://github.com/FraTreppi/better-mc/tree/main/tools/mc-project)

Usa un repository GitHub privato per i contenuti reali del team. Nessun file viene caricato automaticamente su GitHub o Salesforce.
