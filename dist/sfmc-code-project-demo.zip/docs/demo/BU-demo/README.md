# Inventario Marketing Cloud

BU: demo/BU-demo · MID: 123

| Nome | Tipo | Customer Key | Sorgente |
| --- | --- | --- | --- |
| Email demo | asset-email | email-demo | [Apri](assets/6c89810fde26314aeac5.md) |
| Template demo | asset-template | template-demo | [Apri](assets/3b2c03bf337b34937e41.md) |
| CloudPage demo | asset-webstudio | pagina-demo | [Apri](assets/e147953dbcab1de64691.md) |
| Journey demo | journey | journey-demo | [Apri](assets/b3e519d1cb2538dbb0b4.md) |
| Query demo | query | esempio | [Apri](assets/945c7f8471474fdffc05.md) |
