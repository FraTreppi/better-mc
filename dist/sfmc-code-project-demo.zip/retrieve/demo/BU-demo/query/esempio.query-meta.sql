-- Esempio fittizio: nessuna query viene eseguita dalla demo
SELECT SubscriberKey, EmailAddress
FROM [DE-demo]
WHERE IsActive = 1
