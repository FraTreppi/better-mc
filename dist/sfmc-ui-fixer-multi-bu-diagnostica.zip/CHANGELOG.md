# 1.1.34 — 28 ottobre 2026

- Corretto il filtro delle richieste native di copia: riconosce POST /AutomationStudioFuel3/fuelapi/automation/v1/queries/, oltre al percorso senza prefisso. Il percorso effettivo è stato fornito dall’utente tramite Network.
- Il prefisso del modulo viene normalizzato solo nel confronto; la richiesta Salesforce non viene modificata o ripetuta. Rimangono i controlli di origine, metodo, nuovo GUID, procedura e BU.
- Riprodotta la mancata intercettazione con URL prefissato prima della correzione; verificati URL relativo, assoluto e quello corrispondente al percorso utente, con una sola creazione e apertura della nuova query. Guide aggiornate.

# 1.1.33 — 28 ottobre 2026

- Corretto source-route-unrecognized durante Copy Query Activity: il percorso della query originale viene conservato prima della copia e recuperato al clic su Finish anche se Salesforce mostra un percorso temporaneo del wizard.
- La richiesta nativa resta osservata sul percorso temporaneo esatto; dopo il successo si attendono chiusura della procedura e ritorno al dettaglio originale prima di aprire la nuova query. Nessun avviso prematuro durante questa attesa.
- Sorgenti assenti, scadute o di un’altra BU non vengono usate. Annullamento, cambio pagina/BU e risposte tardive rimangono gestiti senza navigazione.
- Riprodotti gli stessi flag della diagnostica utente con la 1.1.32 prima della correzione; prova browser aggiornata e guide Markdown/PDF aggiornate. Nessuna nuova richiesta, scrittura o esecuzione Salesforce.

# 1.1.32 — 28 ottobre 2026

- Scarica diagnostica apertura è ora un comando separato sempre presente in basso a destra nel dettaglio SQL Query Activity, prima di Copy e dopo la chiusura della modale. Non dipende dall’avviso o dal riconoscimento del wizard; Chiudi rimuove soltanto la nota.
- Il comando resta cliccabile sopra gli sfondi modali e viene rimosso quando si lascia il dettaglio della query. Il rapporto aggiunge solo flag dell’ultimo Finish e conteggi di stato, senza SQL, nomi o identificativi.
- Verificati il download prima della copia, Finish interamente non riconosciuto, chiusura della procedura e uscita/rientro nel dettaglio senza duplicati. Nessun nuovo permesso o richiesta Salesforce.

# 1.1.31 — 28 ottobre 2026

- Corretto l’avvio dell’apertura dopo Copy Query Activity quando il comando iniziale è soltanto un’icona. Il titolo nativo del wizard e il clic su Finish identificano la copia, anche senza un precedente Copy testuale riconosciuto.
- Corretto l’annullamento improprio quando Salesforce, dopo aver creato la copia, ripristina o segnala nuovamente il percorso della query originale. I cambi effettivi di attività o BU continuano a invalidare l’apertura.
- Riconosciuti anche contenitori modali senza classi Bootstrap o ruolo dialog, con ricerca limitata e titolo esatto. I wizard Edit/Create Query e Copy Script non avviano la navigazione.
- Una mancata apertura offre il download locale di una diagnostica con passaggi riconosciuti, categorie dei percorsi, stato HTTP e flag; esclusi SQL, nomi, ID, MID, payload e credenziali.
- Riprodotto il mancato avvio della 1.1.30 con Copy a icona; prova browser corretta con il markup Finish fornito dall’utente. Guide aggiornate. Nessun nuovo permesso, scrittura o esecuzione.

# 1.1.30 — 28 ottobre 2026

- Apertura automatica nella stessa scheda della SQL Query Activity appena copiata dal dettaglio, dopo il comando finale e la chiusura della procedura nativa riuscita. Il GUID viene letto dalla risposta Salesforce e sostituisce quello di origine nel percorso già osservato.
- Nessuna copia, salvataggio o esecuzione aggiuntiva. Annullamento, errore, identificativi non validi, scadenza e cambio pagina/BU impediscono la navigazione; il Copy del testo SQL resta separato.
- Verifica browser con bootstrap Automation Studio e richieste native simulate, guide Markdown/PDF aggiornate. Nessun nuovo permesso.

# 1.1.29 — 28 ottobre 2026

- Rimossi Tracking Test, Test History e le anteprime aggiuntive dallo storico; eliminati template e script di navigazione dedicati dal pacchetto e dal manifest.
- Rubrica tester, caricamento automatico dalla DE, suggerimenti e DE recenti conservati. Rimane soltanto l’icona Impostazioni SFMC, con la relativa preferenza di visibilità aggiornata.
- Rimossa la registrazione dei nuovi tentativi di invio. Preview and Test e Send Test nativi restano disponibili; i log precedenti sono conservati e i recenti possono ancora recuperarne i soli riferimenti DE validi.
- Guide Markdown/PDF e verifiche aggiornate.

# 1.1.28 — 27 ottobre 2026

- Sostituito il pannello Tester BU con Carica tester dalla DE: ricerca automatica, verifica dello schema, lettura e attivazione per BU in una sola operazione. Aggiorna tester dalla DE ripete il caricamento; esito e link alla DE compaiono nel menu Impostazioni SFMC.
- Rimossi selettore della sorgente, tabella di inserimento manuale e salvataggio separato. I vecchi contatti restano conservati, mentre i suggerimenti usano soltanto la DE attivata. Nessun invio o modifica a Salesforce.
- Accorpati clic concorrenti e mantenuta la cache appena caricata dopo l’attivazione. Caricamenti falliti, righe tutte non valide e cambi BU non attivano una nuova sorgente. Guide e verifiche aggiornate.

# 1.1.27 — 27 ottobre 2026

- Ricerca automatica della rubrica tester dentro SFMC_UI_Fixer anche nelle sottocartelle della BU. Rimosso il campo percorso manuale; la verifica mostra il percorso rilevato e il collegamento alla DE.
- I vecchi percorsi salvati non limitano la ricerca. Verifica e carica DE ripete l’individuazione, anche dopo uno spostamento della cartella. Nome/External Key tester_content_builder, schema e controlli della radice locale restano richiesti; risultati ambigui non vengono scelti automaticamente.
- Aggiornati prove unit, percorso browser e guida Markdown/PDF. Nessun nuovo endpoint o permesso.

# 1.1.26 — 27 ottobre 2026

- Unificati i recenti di preview nella sola cartella DE recenti della BU, fino a 20 DE distinte. Aggiunto Svuota recenti accanto alla cartella: conserva Test History e le altre cronologie e impedisce il ritorno delle vecchie voci dai log, anche dopo reload o risposte tardive.
- La cartella SFMC_UI_Fixer dei tester può trovarsi in sottocartelle di Data Extensions. Nuovo campo Percorso della cartella tester, verifica esplicita e salvataggio per BU; annullare conserva la configurazione precedente. Nome ed External Key tester_content_builder e schema dei campi restano richiesti.
- Validazione del percorso nel worker, controllo completo della catena di cartelle prima dei record e cache per percorso. Configurazioni esistenti compatibili con SFMC_UI_Fixer direttamente sotto Data Extensions. Guide Markdown/PDF aggiornate.

# 1.1.25 — 26 ottobre 2026

- Le DE usate in una preview riuscita vengono ricordate anche senza Send Test. I recenti della BU restano disponibili cambiando email o template; recuperati anche i riferimenti validi nello storico degli invii esistente.
- Rinominate le cartelle virtuali in DE recenti · questa email e DE recenti · questa BU. Otto DE distinte per elenco, con deduplicazione prima del limite e riferimenti di massimo 60 giorni; nessun valore dei record nel nuovo storico.
- Corretto Load More: scorciatoie aggiunte soltanto alla prima pagina della radice, senza cambiare pagina, dimensione e link nativi; totale coerente nelle pagine successive.
- Letture metadati con sessione AJAX nativa, cache breve, richieste condivise, timeout e invalidazione per BU/email/abort. DE eliminate escluse; errori completati invece di lasciare il selettore in attesa. Guida Markdown/PDF aggiornata.

# 1.1.24 — 26 ottobre 2026

- Rimosso il banner automatico «Automation aggiunta alle viste recentemente», emesso a ogni aggiornamento dei dati e cambio tab Activity/Workflow. La cronologia delle ultime dieci automation continua ad aggiornarsi.

# 1.1.23 — 23 ottobre 2026

- Corrette le conferme ripetute di accesso ai dati locali quando Salesforce ricrea il documento Content Builder. Consenso e rifiuto vengono ricordati per origine esatta, modulo, stack e MID nello storage di sessione protetto, fino a 12 ore dalla scelta.
- Ogni nuovo documento mantiene la propria autorizzazione verificata dal worker; il rinnovo non estende la scadenza. Le richieste concorrenti condividono la prima conferma e un’altra BU richiede una scelta separata.
- Aggiunto nella pagina privata dell’estensione il comando Ripristina le conferme di accesso locale. Invalida le scelte e le autorizzazioni aperte senza cancellare rubriche e copie SQL. Guida Markdown/PDF aggiornata; nessun nuovo permesso.

# 1.1.22 — 23 ottobre 2026

- Corretto Apri sui risultati Advanced fuori dalla griglia: la navigazione viene risolta e invocata attraverso i gestori registrati da Content Builder, anche con pushState e hashchange disattivato. Eliminata l’assegnazione di hash ipotizzati.
- Conferma dell’asset caricato tramite evento dei metadati, oppure cambio di vista con quello stesso asset in cache. Aperture non riconosciute o senza conferma ripristinano pannello, filtri e risultati. Cambio BU e annullamento invalidano le conferme tardive.
- Diagnostica estesa con metodo/esito e schemi statici di navigazione limitati e ripuliti dei numeri, senza ID o nomi degli asset. Nessun nuovo permesso o proxy.
- Verifiche con Backbone reale per risultato fuori pagina, apertura a freddo, cache, rotta assente, comando senza effetto e ripristino. Aggiunte le sole librerie MIT nei fixture di test, separate dai componenti eseguiti dall’estensione. Guida Markdown/PDF aggiornata.

# 1.1.21 — 23 ottobre 2026

- Corretta la scelta del client per Advanced quando Fuel non è esposto: riconosciuti Backbone.ajax e jQuery.ajax della pagina e i relativi moduli AMD già inizializzati. Conservati ajaxSetup, prefilter, beforeSend e opzione useFuel2Token della gestione nativa.
- La query POST non usa più fetch diretto. Se il client nativo non è disponibile viene segnalato senza inviare la POST; un 403 nativo non genera tentativi con un altro client. MID automatico e isolamento delle risposte restano attivi.
- Riprodotto il caso della diagnostica: MID riconosciuto, GET cartelle 200 e POST fetch 403. Aggiunte verifiche browser che richiedono la configurazione AJAX della pagina per accettare la ricerca, compreso il pacchetto realmente caricato in Edge.
- Aggiornati messaggio 403, diagnostica e guida Markdown/PDF per distinguere il numero MID dal collegamento della ricerca. Nessun nuovo permesso, proxy o dato di sessione esportato.

# 1.1.20 — 22 ottobre 2026

- Richieste Advanced allineate al codice nativo Salesforce fornito: scope ours, intestazioni AJAX/versione dati e Content-Type nativo; operatore contains e array values per i tipi. Riconosciuto anche il client fuel-ajax AMD già inizializzato.
- Rilevamento MID automatico in Content Builder da organization.id del contesto della sessione, con timeout breve, rinnovo prima della ricerca e gestione del cambio BU. Nessun ripristino automatico di un MID manuale di un cliente precedente.
- Messaggio 403 distinto dal MID assente e download diagnostico dal pannello, senza Console, token, termini cercati, metadati degli asset o record. Nessun tentativo per aggirare il rifiuto Salesforce.
- Regressioni per intestazioni/scope obbligatori, contesto senza MID nell’URL, cambio BU, moduli AMD e annullamento durante il rilevamento. Guida Markdown/PDF aggiornata.

# 1.1.19 — 22 ottobre 2026

- Aggiunta ricerca Advanced accanto al campo Search di Content Builder. Cerca per nome, Customer Key o ID in tutte le cartelle della BU corrente, con corrispondenza testuale, tipi di asset, cartella specifica, date UTC di ultima modifica e ordinamento.
- Risultati paginati fino a 50 elementi, percorsi cartelle in memoria e apertura nella stessa scheda tramite riga nativa o percorso interno degli asset. Riconosciuti campo Search e righe Content Builder forniti dall’utente; nessuna operazione nel cestino.
- Lettura dei metadati tramite query asset e categorie della stessa origine, con client Fuel quando disponibile. Interruzione, timeout, errori espliciti e protezione dalle risposte obsolete al cambio filtri o BU; nessun nuovo permesso o salvataggio persistente.
- Aggiunte verifiche della query, del client nativo e dell’interfaccia su Chromium/Edge; estesa la prova del pacchetto realmente caricato. Aggiornate guida Markdown/PDF e documentazione di sicurezza.

# 1.1.18 — 22 ottobre 2026

- Pacchetto unico esplicitamente supportato su Google Chrome e Microsoft Edge basato su Chromium. Aggiornate descrizione e istruzioni di download, installazione manuale da edge://extensions, aggiornamento e separazione dei salvataggi locali fra browser.
- Confermate su Microsoft Edge ufficiale le API native del service worker, l’accesso protetto allo storage, l’identità dei documenti, i salvataggi tester per BU e le notifiche alle pagine. Aggiunta una verifica ripetibile del pacchetto realmente caricato, senza simulare le API dell’estensione o modificare policy del browser.
- Messaggio relativo all’identità del documento reso indipendente dal nome del browser. Permessi e controlli di sicurezza invariati. Guida utente Markdown e PDF aggiornata.

# 1.1.17 — 22 ottobre 2026

- Aggiunto Auto refresh 5s ON/OFF nella barra del Run Log in Automation Studio, accanto alle date. Aziona il refresh nativo ogni cinque secondi senza ricaricare la scheda.
- Riconoscimento del pulsante FuelUX refresh fornito dall’utente, limitato al Run Log con due date e comando univoco. Le richieste native jQuery già osservate e i comandi disabilitati sospendono i nuovi clic; il cambio automation o BU disattiva l’automatismo.
- Stato conservato durante la ricostruzione della barra e sospensione mentre il Run Log è nascosto. Nessun nuovo permesso, endpoint o dato persistente.
- Aggiunta verifica browser con timer controllato, richieste lente, sostituzione della barra, cambio automation/BU e comandi ambigui. Guida utente Markdown e PDF aggiornata con le istruzioni della funzione.

# 1.1.16 — 22 ottobre 2026

- Corretta la lettura della rubrica DE quando Salesforce restituisce i campi Email/Nome/Cognome in minuscolo o con maiuscole diverse dai nomi dichiarati nello schema. Gestiti anche i record suddivisi in keys/values.
- La sorgente DE accetta Nome e Cognome testuali fino a 4000 caratteri, senza escludere un contatto valido per il precedente limite di 250 caratteri. Limiti e validazione della rubrica locale restano invariati.
- Le esclusioni indicano motivo e conteggio: Email mancante o non valida, nomi non validi, formato non riconosciuto o campi ambigui. Nessun valore personale nei messaggi. Copie identiche dello stesso campo vengono riunite; valori in conflitto non vengono risolti scegliendo un indirizzo arbitrariamente.
- Salva sorgente resta disabilitato se tutte le righe presenti sono inutilizzabili; una DE realmente vuota resta configurabile. Aggiornate guida e regressioni su lettura, ricerca e selezione dei tester senza invii.

# 1.1.15 — 22 ottobre 2026

- CSV ora esporta l’intera DE selezionata, senza limitarsi alla pagina caricata e senza ereditare filtri della griglia. Lettura paginata di tutti i record, anche 100.000, con adattamento alla dimensione effettiva restituita dal server.
- Avanzamento leggibile, annullamento e blocco del secondo avvio. Cambio DE/BU o uscita da Records annullano il lavoro; le pagine della stessa DE possono essere navigate durante l’esportazione.
- Fino a tre letture contemporanee con ordine di uscita preservato, timeout e tentativi limitati per errori temporanei e rate limit. Blocchi CSV in Blob senza accumulare tutti gli oggetti JSON, conservazione di UTF-8 e protezione dalle formule.
- Validazione di schema, totale, pagine complete e chiavi primarie uniche; controlli finali e download soltanto a lettura completata. Una DE vuota produce le intestazioni. Nessun limite aggiunto di 1000 o 100.000 record e nessuna scrittura nella DE.
- Aggiornate guida Markdown/PDF e regressioni per esportazione completa, 100.000 record, annullamento, cambi contesto, schema e conteggio modificati, errori ed assenza di file parziali.

# 1.1.14 — 22 ottobre 2026

- CSV della pagina corrente separato dalla cache globale dei metadati DE e associato a GUID, BU e singola richiesta. Una nuova richiesta o un cambio contesto invalidano subito i dati; risposte tardive, fuori ordine, errori e pagine vuote non recuperano la copia precedente.
- Cattura dei record tramite prefilter e Deferred jQuery, anche con global:false e percorsi API con maiuscole/minuscole diverse. Copia dei valori prima della formattazione nativa per la griglia; gestione dei campi presenti soltanto in alcune righe.
- Pulsante disabilitato finché la pagina non è disponibile e coerente con il selettore nativo; tooltip con il numero effettivo di righe esportabili, indipendente dal conteggio totale della DE. Nome file con GUID, pagina e numero di righe.
- CSV UTF-8 con BOM, costruzione in blocchi, mantenimento delle protezioni contro formule e dei caratteri speciali. Revoca degli URL Blob dopo il download per liberare le risorse tra esportazioni.
- Aggiunta regressione browser con richieste concorrenti, errori, navigazione A→B→A, cambio BU, risposte senza eventi globali, pagine da DE grandi e carichi di molte righe. Guida utente aggiornata senza risultati di collaudo.

# 1.1.13 — 22 ottobre 2026

- Il documentId fornito da Chrome viene trattato come identificativo opaco, senza presumere un formato UUID. Restano obbligatori mittente dell’estensione, modulo supportato, scheda valida e identità del documento; nessun ripiego su identificativi dichiarati dalla pagina o sul frame.
- Loader e worker verificano la propria versione per riconoscere aggiornamenti incompleti e schede con script precedenti. Gli errori di connessione indicano di ricaricare le schede dopo l’estensione.
- La registrazione non nasconde più la causa: gli errori distinguono mittente, modulo, identità documento, scheda, archivio e versione. Mostrano versione e percorso effettivo, senza URL di sessione o record.
- Gestita anche un’eccezione sincrona all’avvio dello storage protetto, mantenendo una risposta esplicita e l’accesso bloccato. Aggiunte istruzioni per distinguere vecchie segnalazioni conservate da Chrome dagli errori nuovi.

# 1.1.12 — 22 ottobre 2026

- Corretto il rifiuto “Documento non autorizzato” causato dal controllo che accettava solo identificativi documento con trattini. Sono accettati gli identificativi Chrome di 32 cifre esadecimali, mantenendo controllo del mittente, documento, modulo, stack e BU.
- Aggiunta sorgente tester DE condivisa: Data Extensions → SFMC_UI_Fixer → tester_content_builder, con Nome ed External Key esatti e campi Nome, Cognome ed Email. Scelta salvata per BU; rubrica locale precedente conservata come alternativa esplicita.
- Letture GET sulla stessa origine, controllo percorso e schema, paginazione fino a 1000 righe, cache in memoria di cinque minuti e aggiornamento manuale. Nessuna creazione o modifica dei record. Errori visibili, nessun ripiego silenzioso sulla rubrica locale e scarto delle risposte al cambio BU.
- Ricerca asincrona con nome ed email nei suggerimenti; selezionare un tester compila i destinatari senza inviare. Aggiornate guida Markdown/PDF, informazioni sicurezza e CSV dimostrativo.

# 1.1.11 — 21 ottobre 2026

- Ponte storage limitato ai moduli riconosciuti e a una sola chiave: niente letture globali, cancellazioni generali, scritture arbitrarie o notifiche complete alle pagine. Il worker verifica il mittente Chrome e conserva autorizzazioni per documento e BU; l’accesso ai dati locali richiede una conferma dal content script isolato.
- Storage locale e di sessione ristretto ai contesti fidati. Rubriche e copie SQL vengono validate e proiettate sul contesto autorizzato; le scritture restano serializzate. Rubriche fino a 1000 tester.
- Rimosso il proxy fetch generico, il permesso sul dominio degli asset sfmc-content.com e il componente SMS aziendale inattivo. Le pagine interne privilegiate non sono più risorse accessibili ai siti; aggiunta una policy restrittiva per le pagine dell’estensione.
- Codificati i valori inseriti nelle interfacce, incluso l’oggetto delle anteprime, i nomi delle automation e i metadati Query Studio. Le anteprime usano sandbox, contenuto inerte e policy di rete restrittiva; le immagini esterne richiedono un consenso esplicito per anteprima.
- Controllo SMS interamente locale, con conteggio GSM/esteso/Unicode; CSV protetti dai prefissi di formula. Limitati i campi dei log e degli snapshot, ripuliti i vecchi snapshot e i modelli URL non più usati, rimossi dump di anteprime/SQL dalla console.
- Aggiunte Guida utente Markdown/PDF con tutte le funzionalità e relative istruzioni, senza risultati di collaudo, e documentazione dedicata alla sicurezza. Sostituita la vecchia guida per il collaudo.

# 1.1.10 — 21 ottobre 2026

- Il pulsante accanto a Send Test ora si chiama **Tracking Test**.
- La ricerca della cartella usa le etichette native nei frame sotto fraLeftNav, senza imporre un valore a strCurSect o un nome al frame dell’albero.
- Menu, caricamenti e modifiche del DOM attivano subito i controlli; resta un polling di riserva a 100 ms. L’elenco dei test già aperto viene riconosciuto dal titolo o dall’intestazione/breadcrumb del contenuto, evitando un clic e un caricamento aggiuntivi.
- Le fasi che avanzano ricevono ciascuna fino a 20 secondi, entro un limite totale di 60 secondi. Dopo un errore, il controllo prosegue per due minuti in sola osservazione: se l’elenco si apre, anche manualmente, l’avviso e il pulsante diagnostica spariscono. Nessuna ulteriore navigazione o clic automatico dopo l’errore.
- Gli avvisi hanno il pulsante **Chiudi** e scompaiono comunque dopo 30 secondi. Le prove con i moduli nativi e server simulati coprono anche elenco ripristinato, breadcrumb legacy, frame rinominato, contenuto aggiornato sul posto e apertura tardiva. Nessun nuovo permesso.

# 1.1.9 — 21 ottobre 2026

- Tracking test avvia Email Studio tramite Subscribers, l’ingresso usato dal collegamento DE funzionante, conservando l’intento Tracking nel marcatore dedicato e selezionando il menu dopo l’avvio.
- Gestito il menu nativo inizializzato ma ancora privo di curNavItem: se esistono il frame legacy e la voce Tracking nei metadati nativi, viene riattivato una sola volta il normale listener di selezione. Non vengono costruiti modelli di menu fittizi né usata la rotta che rimuove la vista.
- Gli errori offrono Scarica diagnostica tracking: rapporto locale con flag di inizializzazione, presenza dei frame e sezioni native note, senza URL di sessione, credenziali o record. Nessun invio automatico.
- Riprodotto il timeout 1.1.8 su un menu non selezionato e verificato il recupero con i moduli nativi e server simulati. L’effettiva inizializzazione nel tenant dell’utente resta da verificare. Nessun nuovo permesso.

# 1.1.8 — 21 ottobre 2026

- Corretto il passaggio a Tracking: usa lo stato del menu nativo e non richiama più la rotta generale con trigger, che in switchPage può rimuovere la vista corrente. Riconosce il menu da curNavItem anche quando sectionId è nullo, uno stato valido della UI nativa.
- La selezione di Test Send Emails attende il caricamento del contenuto in fraContent prima di dichiarare aperta la destinazione. Gestite anche le etichette span con gestori di clic assegnati dal codice nativo.
- Aggiunti messaggi distinti per inizializzazione, menu Tracking, cartella mancante ed elenco non caricato.
- Riprodotta la pagina bianca della versione precedente usando il router nativo. Verificata la correzione con Backbone 0.9.10 e i moduli navView/uiView/legacyView forniti per l’analisi, su pagine simulate. Collaudo autenticato ancora necessario; nessun nuovo permesso.

# 1.1.7 — 21 ottobre 2026

- Corretto l’errore postMessage “target origin … members … does not match … mc” nelle aperture di DE e Tracking test. La shell non invia più richieste all’origine dedotta da iframe.src durante il caricamento o il passaggio SSO.
- Il documento C12 caricato annuncia un MessageChannel dedicato; la shell verifica origine reale, stack e finestra mittente prima di utilizzarlo. Supportati C12 su members e mc dello stesso stack, senza destinazioni wildcard. I canali vengono chiusi al completamento o all’annullamento.
- Riprodotto l’errore originale nel browser e verificati caricamento ritardato, reindirizzamento members → mc, passaggio da SSO, UI moderna/legacy, stack diversi e cancellazione. Prove su pagine simulate; verifica nella sessione Salesforce ancora necessaria. Nessun nuovo permesso.

# 1.1.6 — 21 ottobre 2026

- Aggiunta nelle impostazioni dell’estensione una scelta persistente per nascondere completamente entrambe le icone di Preview and Test e riattivarle dalla barra del browser. Preferenza generale del profilo, indipendente dal MID; tester e storico non vengono eliminati.
- Aggiunto Tracking test accanto a Send Test. Apre lo stack corrente e seleziona la cartella nativa Test Send Emails tramite fraLeftNav/fraTree. Attesa limitata e messaggio se la cartella non è disponibile; nessun invio automatico o ID di cartella fisso.
- Preparato il collegamento Apri Data Extension sull’entry del Journey: lettura della versione e della definizione evento, GUID esplicito della DE, aggancio a identificatori nativi dell’entry e rifiuto di risposte obsolete/ambigue. Il posizionamento nell’interfaccia dell’utente richiede ancora verifica dell’HTML dell’entry.
- Nessun nuovo permesso. Prove con pagine e risposte API simulate; verifica autenticata dei nuovi collegamenti ancora necessaria.

# 1.1.5 — 21 ottobre 2026

- Sostituita la barra flottante MID/Tester BU con un’icona Impostazioni SFMC accanto a Test History, solo in Preview and Test. Menu con due opzioni, chiusura con clic esterno o Escape e uso da tastiera. Nelle Data Extension non compaiono i controlli; uscendo da Preview and Test si chiudono menu, rubrica e storico aperti.
- Rubrica tester con campi Cognome/Nome/Email, aggiunta e rimozione di righe, validazione delle email e conferma del numero di contatti salvati. Nessun limite fisso al numero di tester; verificati dieci contatti, recupero dopo il ricaricamento e separazione tra BU. I tester già salvati restano compatibili.
- Nessun nuovo permesso o invio automatico di email. Il collegamento Email Studio resta invariato.

# 1.1.4 — 21 ottobre 2026

- Corretto il caso in cui la shell Email Studio scarta il percorso della DE e apre il solo modulo Subscribers. Il GUID viene acquisito all’avvio della pagina e inviato al frame C12 dello stesso stack quando il router è pronto; conferma del percorso, attesa limitata e annullamento quando si cambia modulo.
- Aggiunti suggerimenti per Imposta MID e Tester BU. La rubrica spiega il suo uso in Content Builder e chiede prima di impostare il MID se manca il contesto necessario per salvarla.
- Rubrica tester persistente nel browser: chiarito il salvataggio per stack/MID. Dopo un ricaricamento il pulsante ricorda il MID manuale come suggerimento da riconfermare, senza riusare automaticamente la BU di un altro cliente.
- Nessun nuovo permesso richiesto; il collegamento non richiede il MID manuale. La barra resta rimossa dal Journey Builder e dai suoi frame. Prove locali con frame di origini diverse e router nativo; collaudo autenticato della correzione ancora necessario.

# 1.1.3 — 21 ottobre 2026

- Contact Builder → Email Studio: apertura automatica tramite la rotta nativa `Subscribers/Data_Extensions/<GUID>/edit`, ricavata dal router Email Studio fornito per l’analisi. Stack rilevato dal contesto, nessun URL o MID da configurare per usare il collegamento.
- Rimossi la richiesta del modello URL e il pulsante Link Email Studio. I vecchi modelli salvati vengono ignorati. Il GUID viene ricalcolato al clic, anche con il pulsante centrale; la navigazione usa la sessione Email Studio corrente senza cambio BU automatico.
- La barra SFMC Fixer resta rimossa dal Journey Builder e dai suoi frame. Collaudo reale dell’apertura sul tenant ancora necessario.

# 1.1.2 — 21 ottobre 2026

- Rimossi barra e menu SFMC Fixer dal Journey Builder e dai documenti incorporati nel Journey, inclusi i frame con hostname differente. Resta disponibile il collegamento alle referenze dei Journey; la barra degli altri moduli resta disponibile quando aperti autonomamente.

# 1.1.1 — 21 ottobre 2026

- Diagnostica Email Studio v2: raccolta delle stringhe di navigazione nei tre bundle nativi già caricati, memoria delle richieste recenti anche dopo il riempimento del buffer del browser, attesa dei frame con analisi in corso e indicazione dei risultati incompleti. Nessuna lettura dei record o delle risposte API, nessun nuovo permesso.
- Aggiunta diagnostica di sola lettura per il collegamento Contact Builder → Email Studio: raccolta esplicita dei percorsi dei frame e delle richieste, parametri filtrati, anteprima ed esportazione JSON senza invio automatico. Nessun nuovo permesso richiesto. L’apertura automatica del dettaglio resta da implementare dopo la verifica del percorso nativo.
- Journey Builder: barra di configurazione raccolta in un menu inizialmente chiuso in alto a destra, anche nei frame delle attività, per lasciare liberi Done/Cancel e zoom. Chiusura con clic esterno o Esc.

# 1.1.0 — 20 ottobre 2026

- Autore della versione Multi BU: Francesco Trepiccioni; aggiunta guida rapida di collaudo per i colleghi, in Markdown e PDF.

- Copia separata della versione 1.0; `stable` originale conservata.
- Individuazione dello stack dal contesto corrente, senza fallback s7.
- Identificazione del MID quando esposto dalla pagina; alternativa manuale per documento.
- Cronologie DE, automation, test send e query salvate separate per stack/MID; memoria temporanea quando il contesto è sconosciuto.
- Destinatari di test configurabili per BU; elenco personale originale escluso dal distribuibile.
- Link Contact Builder → Email Studio con modello configurabile per BU, aggiornamento su navigazione SPA e controllo del GUID al clic. Necessita calibrazione sul tenant.
- Rimozione degli ID operativi fissi di DE e cartelle dai moduli attivi; rilevamento della radice DE per le cartelle virtuali delle anteprime.
- Endpoint di inserimento righe relativi al dominio Contact Builder corrente.
- Snapshot SQL separati per stack/MID, visualizzatore aggiornato, esportazione dello storico e cancellazioni serializzate che preservano nuovi snapshot concorrenti.
- Caricamento del modulo DE anche entrando direttamente sul dettaglio o navigando da altre sezioni Contact Builder.
- Correzioni a ricerca con caratteri speciali ed errori HTTP, cronologia vuota dopo cambio BU, callback jQuery, CSV con virgolette/separatori/a capo, autocomplete, query con Unicode e preview email in iframe sandbox.
- Proxy fetch limitato a letture HTTPS Marketing Cloud; permesso tabs rimosso, risorse accessibili coerenti con i domini di caricamento.
- Suite di regressione locale e script di packaging ripetibile.

Verifica automatica locale completata. Compatibilità reale di moduli, API interne, selettori, permessi, DE condivise e collegamento Email Studio da collaudare su Marketing Cloud.
