# SFMC UI Fixer — Documentazione tecnica

Per le istruzioni operative usare [GUIDA_UTENTE.md](GUIDA_UTENTE.md). Le protezioni attuali sono descritte in [SICUREZZA.md](SICUREZZA.md). Le sezioni storiche seguenti descrivono anche versioni precedenti; la versione 1.1.11 sostituisce il ponte generico con operazioni limitate al modulo, al documento e alla BU autorizzati.

Analisi del 20 ottobre 2026. Oggetto: i file presenti nella cartella `stable`, non una sessione Marketing Cloud autenticata. Le indicazioni sulle funzionalità derivano dalla lettura dei sorgenti; i test della nuova versione usano dati e interfacce simulate. Dove un comportamento dipende da Salesforce è indicato esplicitamente.

## Versione attuale 1.1.42 — 24 novembre 2026

Il riquadro interno può contenere solo il titolo **CloudPages**, la barra **Search** e l’elenco. L’estensione riconosce il titolo fuori dalla tabella e le righe che hanno le colonne attese e il controllo azioni Salesforce associato all’ID asset. In caso di intestazioni fisse separate, preferisce il contenitore che contiene le righe. Il contenitore con le intestazioni è utilizzabile anche quando il filtro nativo lascia l’elenco vuoto.

Le prove browser includono un iframe annidato con il titolo CloudPages, la guida della ricerca come testo separato, una tabella per le intestazioni e una per i risultati. Verificano che il campo sia sopra le righe, che il filtro nativo venga conservato e che lo scorrimento possa trovare un Page ID in un’altra posizione. La prova usa dati simulati.

## Versione 1.1.41 — 24 novembre 2026

La vista **Overview** può mostrare l’indicazione «Enter at least three characters to search» sotto la ricerca Salesforce. Il modulo Page ID riconosce la vista anche tramite le etichette **CloudPages**, **Overview** e **Recycle Bin** e riconosce la ricerca tramite il testo di aiuto. Gestisce intestazioni e righe di tabelle e griglie accessibili. Se l’elenco visualizza un conteggio aperto, per esempio **20+ items**, usa lo scorrimento del riquadro quando **Load More** non è visibile. La mancata conferma della copertura rimane un esito parziale.

La schermata dell’utente ha fornito le etichette visibili e il layout. Le verifiche automatiche riproducono queste caratteristiche con dati simulati. Il markup effettivo e l’esito della scansione sul tenant autenticato restano da verificare.

## Versione 1.1.40 — 24 novembre 2026

Il primo argomento di `CloudPagesURL()` corrisponde al campo **Page ID** dei dettagli della landing page. Il modello REST Content Builder pubblica l’attributo `id` dell’asset e non documenta un attributo ricercabile con questa corrispondenza. Salesforce precisa inoltre che creare un asset `webpage` di tipo 205 non lo crea nell’interfaccia CloudPages. La ricerca usa quindi il valore con etichetta **Page ID** visibile nella UI. [CloudPagesURL](https://developer.salesforce.com/docs/marketing/marketing-cloud-ampscript/references/mc-ampscript-sites/mc-ampscript-reference-sites-cloud-pages-url.html), [dettagli pagina su Trailhead](https://trailhead.salesforce.com/content/learn/modules/custom-preference-center-development/build-your-preference-center), [attributi REST](https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/asset-attribute-list.html), [tipo di asset](https://developer.salesforce.com/docs/marketing/marketing-cloud/guide/asset_type.html).

`assets/js/cloudpages-links.js` inserisce il modulo **Page ID** sopra l’elenco nativo. La selezione di **All Pages**, il caricamento con **Load More** e l’apertura dei dettagli usano i controlli del documento CloudPages corrente. La corrispondenza è un confronto tra interi decimali rappresentati come stringhe, con zeri iniziali normalizzati. Il nome, la posizione e l’ID asset provengono dalla riga che ha aperto i dettagli. La riga viene identificata nuovamente prima dell’apertura nativa del risultato. Se i dettagli sono una schermata a sé, una corrispondenza resta aperta e per proseguire dopo una mancata corrispondenza serve il collegamento nativo **Home**.

La scansione dipende dall’inventario esposto da **All Pages** e dai permessi della BU attiva. Se All Pages senza filtri non è confermata, se markup, paginazione o dettagli non sono leggibili o se l’inventario contiene elementi non attraversabili, il risultato è parziale. Non è stato individuato un metodo documentato per enumerare per Page ID pagine assenti da All Pages, per esempio contenuti in cartelle o micrositi che la vista non espone. Anche un esito senza corrispondenze è limitato alle pagine verificate. L’operazione ha un limite di cinque minuti, e l’interazione con Salesforce o un cambio di contesto la interrompe.

Verifica 1.1.40. I 74 test unitari includono il motore DE e il consenso condiviso per BU. Le prove browser caricano l’estensione in Chromium e Microsoft Edge e usano pagine Salesforce simulate per verificare Page ID e ID asset distinti, attraversamento di cartelle tramite All Pages e Load More, apertura nativa, filtri, annullamento, cambi BU e scansioni parziali. L’associazione fra Page ID e `CloudPagesURL()` è confermata dalle fonti Salesforce. La compatibilità con il markup e i permessi di un tenant Salesforce autenticato resta da verificare.

## Versione 1.1.39 — 12 novembre 2026

La richiesta utente sostituisce il componente Node con un’integrazione interamente nell’estensione e un consenso unico per BU. Rimossi strumenti e ZIP del servizio locale. I sorgenti src/de-usage sono compilati con esbuild in due bundle locali: de-usage-offscreen.js (SOAP/indice/motore) e de-usage-sql-worker.js (solo parser TransactSQL). Le versioni delle dipendenze sono fissate nel package-lock; licenze incluse in assets/THIRD_PARTY_LICENSES.txt. Node serve soltanto a sviluppo e build, non all’utilizzo.

Background verifica mittente, ruolo Contact Builder, documentId, scheda, GUID della DE nella route, stack/MID configurati e grant BU prima di inoltrare azioni predefinite al documento offscreen. Runtime.getContexts e creazione condivisa evitano duplicati; il requisito Chromium minimo è 116 e il nuovo permesso è offscreen. Rimossi gli host HTTP loopback; aggiunti soltanto HTTPS auth/soap marketingcloudapis.com. Le risorse del motore, worker, impostazioni e credenziali restano private e non web-accessible.

La pagina privata richiede checkbox e Salva e autorizza questa BU solo in assenza di consenso valido, verifica OAuth prima del salvataggio e registra il consenso bu-v2|stack:MID. Un consenso già valido viene riutilizzato dalla configurazione API senza checkbox aggiuntiva e senza estensione della scadenza, ricontrollandone la validità dopo OAuth. Lo storage local rimane TRUSTED_CONTEXTS; il segreto non viene restituito dalla lettura delle impostazioni, dai risultati o dalle notifiche, né salvato in sync. L’input viene svuotato al termine del tentativo. È una memorizzazione locale senza cifratura aggiuntiva, esplicitata nelle istruzioni. Il token è conservato solo dal motore e rinnovato usando expires_in, senza popup. Configurazione e scansione rimangono su una singola BU.

Il consenso v2 comprende rubrica, copie SQL e analisi DE, condiviso fra i moduli supportati della BU fino a 12 ore nella sessione. I grant restano per documento, ruolo, origine/percorso e scheda; la condivisione della decisione non amplia le chiavi accessibili a ciascun modulo. Il loader isolato espone ensure soltanto agli altri content script dell’estensione; il ponte della pagina continua a consentire soltanto get/merge filtrati. Analisi DE gestisce LOCAL_ACCESS_REQUIRED riusando il loader e senza popup aggiuntivo se la BU è già approvata. Vecchie approvazioni/grant senza consentVersion=2 non autorizzano la nuova funzione. Diniego, scadenza, reset e stack/MID differenti conservano il blocco delle letture.

Il documento offscreen accetta comandi soltanto dal background, mai dai content script o da pagine private diverse. SQL nel worker senza credenziali, timeout 2,5 secondi, massimo 500 KB. OAuth e SOAP esclusivamente documentati; account_id e ClientIDs fissi, QueryAllAccounts=false, endpoint con host validato, redirect e cookie vietati, errori redatti. Validazione di Describe, paginazione, AST SQL, target, relazioni e copertura parziale conservate dalla 1.1.38. Indice in memoria con refresh condiviso; token riutilizzato tra scansioni. Reset e cancellazione invalidano generazioni, interrompono fetch e scartano configurazioni o risultati tardivi. Nessuna lettura record, invio o esecuzione query introdotta.

Verifica 1.1.39: 74 test unit estensione/motore, prove browser del pannello con loader e consenso unico, prova del bundle offscreen con Web Worker SQL effettivo, richieste OAuth/SOAP simulate, rinnovo automatico, risultati parziali, svuotamento e modulo privato di configurazione. Regressioni browser rubrica, DE recenti e copia query. Audit npm senza vulnerabilità note alla verifica. Il caricamento reale come estensione è stato tentato con Chromium 154 installato: nessun service worker esposto entro 15 secondi. Controllata anche chrome://extensions in un profilo di prova: risultava soltanto Chromium PDF Viewer, senza la nostra estensione caricata dai flag di avvio. Non è una verifica positiva in Edge. Non è disponibile un tenant autenticato: permessi effettivi, retrievability SOAP e interfaccia Salesforce restano da verificare con il pacchetto dell’utente.

## Versione 1.1.38 — 12 novembre 2026

Base ripristinata dal pacchetto utente 1.1.37 (SHA256 ec2a6d7e14b37e251947e3d850b23630cf039c7076ba3ab31cb8e84e4007841a). I successivi strumenti export/Git non fanno parte di questa versione.

Il content script isolato de-usage-content crea un pulsante nel contenitore #dataExtension sulla route Contact Builder #admin/data-extension/GUID. Il ponte MAIN de-usage-context trasferisce soltanto lo scope corrente. Il worker privato verifica documento, ruolo, stack/MID configurati, GUID nella route e azione; nessuna richiesta di rete generica. La pagina privata de-usage-settings salva la sola chiave del componente. Il pannello usa textContent, link su stack fisso, paginazione di 200 righe e generazioni per scartare risposte dopo cambio DE.

Il componente tools/de-usage serve 127.0.0.1:17638 con Host/origine/Bearer e scope verificati. OAuth account_id, SOAP ClientIDs e QueryAllAccounts=false vincolano la lettura. Il token e il soap_instance_url con host Salesforce validato vengono riutilizzati. Sono consentiti solo Describe e Retrieve sui cinque tipi di metadati previsti. Describe seleziona le proprietà effettivamente leggibili; proprietà minime mancanti producono errore, relazioni automation non disponibili producono copertura parziale. Non vengono interrogati endpoint privati dell’interfaccia per questa funzione.

QueryText è analizzato tramite AST TransactSQL (node-sql-parser 5.4.0) in worker con timeout. Si estraggono sorgenti fisiche, escludendo CTE, stringhe e commenti. I nomi DE sono risolti esattamente, senza sottostringhe e senza scegliere fra duplicati. I target usano ObjectID/CustomerKey con controllo di concordanza. Le automation conservano più occorrenze della stessa query e preferiscono ProgramID per la navigazione. Il recupero considera task annidati e, se necessario e supportati, oggetti task/activity separati. Mancanza di metadati, step incerti, ENT e SQL non supportato restano espliciti. I risultati non includono SQL, record o credenziali Salesforce.

Limiti: 10 minuti per lettura/indicizzazione, 25 MB per risposta, 100 MB cumulativi, 100.000 risultati per tipo e 1.000 pagine, 500 KB/2,5 secondi per query SQL. L’indice è solo in memoria e rimane datato fino a refresh/riavvio. La scansione è condivisa fra richieste concorrenti; un refresh fallito conserva il vecchio indice con avviso. Non è una fotografia transazionale di Salesforce. Le letture possono essere limitate dalle autorizzazioni del pacchetto senza consentire di provare l’assenza di tutti gli utilizzi.

Verifica: 58 test unit dell’estensione e 11 del componente; prova browser del pannello/context bridge con dati simulati per clic attendibile, nomi sicuri, risultati parziali, paginazione e navigazione. Regressioni browser tester, DE recenti e apertura copia query. npm audit del componente non segnala vulnerabilità note alla data della verifica. Verificati anche estrazione del pacchetto, installazione pulita con npm ci, test del componente estratto, configurazione interattiva con Client Secret sintetico non mostrato, permessi 0600 e status loopback autenticato senza chiamate al tenant. La prova di caricamento reale dell’estensione su Chromium installato è stata tentata: nessun service worker reso disponibile entro il timeout. Non equivale a una verifica del pacchetto in Edge. Le prove non usano credenziali Salesforce: restano da verificare sul tenant Installed Package, proprietà SOAP retrievabili, link e markup nativi effettivi.

## Versione 1.1.37 — 2 novembre 2026

Ripristinato soltanto il collegamento Tracking Test dalla versione precedente alla rimozione 1.1.29: posizionato dopo il pulsante nativo Send Test visibile, una sola istanza, nuova scheda con rel noopener noreferrer e stack corrente. Usa la stessa superficie Preview and Test del toolbox; viene rimosso fuori dal pannello e ricreato al ritorno, indipendentemente dall’opzione che nasconde Impostazioni SFMC.

Ripristinati test-tracking-shell.js a document_start nella shell e test-tracking-main.js nel mondo MAIN del documento C12. Non sono risorse web accessibili e non usano API extension/storage. Il canale privato verifica origine, iframe e richiesta; la selezione usa _NavState e la voce Test Send Emails nei soli frame di navigazione nativi. Conservate le correzioni precedenti per curNavItem mancante, sectionId già Tracking, documenti ritardati e annullamento. Eliminato dal ripristino il download della diagnostica e il relativo rapporto; resta soltanto l’eventuale avviso chiudibile. Non vengono rimessi hook di invio, Test History o template delle preview dai log.

Verifica 1.1.37: passati 56 test unit, sintassi di 53 file JavaScript, prova browser Tracking, regressioni browser rubrica tester e DE recenti; guida PDF rigenerata e testo/versione verificati. La verifica del pacchetto realmente caricato come estensione in Edge non è stata rieseguita in questa revisione.

Le prove browser usano Backbone 0.9.10 e risposte simulate per verificare selezione Tracking/cartella una sola volta, recupero del menu, elenco già aperto, vista di base preservata, navigazione normale senza marcatore, annullamento e timeout. Le prove del bootstrap Content Builder verificano posizione/visibilità del link insieme alla rubrica tester e l’assenza di Test History; l’invio nativo simulato resta una sola richiesta e non modifica i vecchi log. Non è disponibile una sessione Salesforce autenticata per verificare la navigazione sul tenant.

## Versione 1.1.36 — 2 novembre 2026

Nuovo content script isolato cloudpages-links.js, privo di API storage o rete aggiuntive. Il markup fornito identifica tr.slds-hint-parent, celle Name/Location/Type/ID/Status/Modified/Actions e il suffisso SLDSDataTableRow-ID-SLDSDataTableRowActions. L’URL della shell fornito resta /cloud/#app/CloudPages/ anche con editor aperto: non viene assunto un percorso editor.

Un link HTTPS alla shell dello stack corrente apre una nuova scheda con ID e nome temporanei nella query string. La shell riconosce il proprio iframe diretto tramite origine HTTPS Salesforce dello stesso stack ed event.source; il frame dichiara la libreria solo dopo aver riconosciuto la tabella. La selezione viene eseguita una volta con il clic nativo sulla cella del nome e richiede ID/nome esatti e riga visibile. Se manca la riga, il campo identificato dal placeholder presente nella schermata utente riceve input/change/Enter nativi con il nome. Non vengono osservati o costruiti endpoint. Il rendering diretto nella shell e una tabella inizialmente vuota sono gestiti.

L’osservatore DOM aggiorna le sole righe aggiunte/modificate; l’attesa periodica esiste solo nella nuova scheda con apertura pendente. Scadenze di 30 secondi nel frame e 45 nella shell, cambio modulo e interazioni utente interrompono la selezione. Nessuna scrittura Salesforce o accesso allo storage. La risposta selected conferma l’invio del clic nativo, non certifica il caricamento remoto dell’editor: l’apertura effettiva dipende dal comportamento Salesforce.

Verifica 1.1.36: passati i 56 test unit e la sintassi di 50 file JavaScript. La prova browser CloudPages passa per apertura in nuova scheda con origine invariata, ricerca e selezione una sola volta, nomi con caratteri speciali, rendering in iframe o direttamente nella shell, elenco inizialmente vuoto, riga già presente, Load More, riuso e rinomina delle righe, rifiuto di ID/nome non corrispondenti, timeout, interazione utente e risposte tardive dopo cambio modulo. Guida PDF rigenerata e verificata per testo/versione.

Le prove browser usano il markup strutturale fornito con nomi/ID sintetici, shell e iframe simulati. Non è disponibile una sessione tenant per verificare il contenitore, i filtri e il caricamento effettivo dell’editor. La pubblicazione GitHub resta una distribuzione ZIP manuale: nessuna promessa di aggiornamento automatico per copie decompresse e nessun caricamento di codice remoto.

## Versione 1.1.35 — 28 ottobre 2026

Dopo la conferma utente di apertura riuscita nella 1.1.34 (navigated e creazione HTTP 201), rimossi interamente dall’interfaccia il pulsante Scarica diagnostica apertura, l’avviso automatico, la generazione/download del JSON e il relativo CSS. Non esiste un ripiego che li mostri dopo errori o timeout. Lo stato tecnico interno in memoria resta disponibile alle verifiche automatiche.

Il ricordo della query sorgente prima associato al montaggio del controllo è stato conservato come chiamata autonoma, all’avvio e ai cambi di percorso/BU. La navigazione mantiene il comportamento verificato con il prefisso AutomationStudioFuel3/fuelapi e il percorso temporaneo del wizard. Nessun nuovo permesso o richiesta Salesforce.

Le prove browser dei sorgenti verificano l’assenza dei controlli all’apertura, dopo il successo e dopo una richiesta non riconosciuta fino al timeout, oltre alle regressioni native di copia/navigazione. Passati anche i 56 test unit e la verifica sintattica di 48 file JavaScript; guida PDF 1.1.35 aggiornata. Le risposte sono simulate, senza creazioni reali di attività nel tenant.

## Versione 1.1.34 — 28 ottobre 2026

Il nuovo rapporto utente conferma la correzione precedente (origine, wizard e Finish riconosciuti), ma riporta native-request-unrecognized con requests vuoto. L’utente ha poi fornito Request Method POST e il percorso /AutomationStudioFuel3/fuelapi/automation/v1/queries/. Il filtro della 1.1.33 era ancorato a /fuelapi/automation/v1/queries/ e scartava questa richiesta prima di registrarne la risposta.

La correzione normalizza il solo prefisso fisso /AutomationStudioFuel3 per il confronto dei percorsi. Non cambia URL, opzioni AJAX, metodo o payload e non emette nuove richieste. La validazione dell’origine resta obbligatoria; restano autorizzate alla navigazione soltanto le POST della collezione query o del copy/clone della sorgente, con un nuovo queryDefinitionId valido e procedura/BU coerenti.

Prima della correzione, la fixture con il percorso prefissato riproduce la mancata intercettazione e requests vuoto. Dopo la correzione passano le varianti con URL assoluto, relativo e percorso completo corrispondente a quello fornito dall’utente; ogni caso verifica un’unica POST nativa e apertura della nuova query. Le altre regressioni di navigazione, isolamento e diagnostica continuano a passare. Passati i 56 test unit, la verifica sintattica di 48 file JavaScript e la rigenerazione della guida PDF 1.1.34. Le prove usano risposte simulate, senza creare attività reali in Salesforce.

## Versione 1.1.33 — 28 ottobre 2026

La diagnostica fornita dall’utente riporta copyWizardRecognized=true e finishRecognized=true insieme a sourceRouteRecognized=false, sourceQueryLoaded=false, result=source-route-unrecognized e nessuna richiesta osservata; dopo la chiusura runtime.queryDetail torna true. Il riconoscimento si interrompeva perché assumeva che il dettaglio originale fosse ancora nel percorso al clic su Finish.

Prima della correzione, una fixture con Copy a icona, percorso temporaneo non ActivityDetails durante il wizard e ritorno nativo all’originale riproduce esattamente questi flag e il mancato cambio di query. Ora il dettaglio valido osservato prima della copia viene ricordato soltanto in memoria, per documento/BU e al massimo dieci minuti; il clic sul comando sorgente aggiorna l’osservazione anche con icona senza etichetta. Al Finish di un Copy Query Activity riconosciuto, se il percorso è temporaneo viene recuperata quella sorgente osservata. Nessun ID sorgente viene indovinato o ricavato dal wizard. Durante la richiesta si ammette soltanto l’esatto percorso temporaneo catturato per quell’operazione; dopo successo e chiusura si attende il ritorno nativo al dettaglio originale e si sostituisce solo il GUID con quello restituito dalla creazione.

La diagnostica aggiunge soltanto sourceFromRememberedDetail, wizardRouteDifferent e conteggi limitati degli eventi, senza valori dei percorsi o degli ID. Sorgente mai osservata/scaduta, cambio BU, annullamento e navigazione effettiva impediscono l’apertura. Un ritorno nativo ritardato non produce una nota di fallimento prematura.

Verifica della 1.1.33: la regressione che prima riproduceva il rapporto utente passa; i browser test coprono anche ritorno nativo ritardato, risposta tardiva dopo annullamento/cambio BU/navigazione, sorgente non osservata o scaduta e assenza di dati applicativi nel rapporto. Passati anche i 56 test unit e la verifica sintattica di 48 file JavaScript; guida PDF 1.1.33 rigenerata. Le richieste native sono simulate; non vengono create attività reali e manca una sessione Salesforce autenticata per la conferma sul tenant.

## Versione 1.1.32 — 28 ottobre 2026

La diagnostica della 1.1.31 dipendeva dal riconoscimento del flusso e dall’avviso rimosso al cambio di vista. Ora un controllo indipendente è montato direttamente nel body del dettaglio ActivityDetails/300, prima di Copy e senza richiedere metadati in cache. Rimane dopo la chiusura della modale o della nota, con un livello visivo sopra gli sfondi modali; si rimuove uscendo dal dettaglio SQL e si ricrea una sola volta al rientro. Il download continua a usare soltanto un Blob locale; non aggiunge richieste Salesforce. La nota automatica riutilizza il comando esistente, evitando due pulsanti uguali.

Il rapporto aggiunge queryDetail, numero di client osservati, conteggio limitato delle modali visibili e soli flag dell’ultimo Finish. Un Finish non riconosciuto produce finish-unrecognized senza creare un intento di navigazione. Non vengono raccolti SQL, nomi, ID, MID o valori delle risposte.

Verifica 1.1.32: prova browser con bootstrap Automation Studio e fixture Salesforce passata per diagnostica disponibile prima di Copy, download idle senza richieste aggiuntive, download cliccabile anche sopra uno sfondo modale simulato con z-index 1040, Finish con titolo non riconosciuto, assenza della nota automatica e permanenza del comando dopo la chiusura del wizard, rapporto senza dati applicativi, rimozione in Overview e ripristino unico al ritorno. Le regressioni di copia e navigazione continuano a passare, insieme ai 56 test unit; sintassi di 48 file JavaScript e guida PDF verificate. La conferma sul tenant resta da raccogliere attraverso il rapporto. Le verifiche non usano una sessione Salesforce autenticata né creano attività reali.

## Versione 1.1.31 — 28 ottobre 2026

Il mancato avvio con Copy a icona è stato riprodotto prima della correzione. Il wizard viene ora riconosciuto dal titolo Copy Query Activity al clic su Finish, senza dipendere dall’etichetta del comando iniziale. La fixture usa il markup Finish fornito dall’utente (button type=button, classi btn btn-primary accept, title e data-original-title vuoti). Il riconoscimento copre anche contenitori modali senza classe Bootstrap o ruolo dialog, richiedendo un contenitore modal/dialog/wizard/activityConfig e titolo esatto entro dodici antenati. Il percorso ActivityDetails valido insieme al wizard può identificare il flusso anche se la cache dell’estensione non contiene ancora i metadati della query.

Il log dell’utente mostra inoltre il caricamento del nuovo identificativo seguito dal ritorno Salesforce al percorso ActivityDetails della query originale. Riprodotto l’annullamento improprio della navigazione in questa sequenza: ora gli eventi che riportano alla stessa attività sorgente, compresa normalizzazione di case e slash finale, conservano l’apertura pendente. Cambi effettivi di attività/BU, Escape, annullamento e scadenza continuano a invalidarla. È controllato anche newURL dell’evento, senza conservarne il valore.

Le richieste jQuery sono osservate sulle sole istanze già inizializzate della pagina, Backbone e AMD; registrazione una volta per istanza, senza inviare o modificare richieste. Una mancata apertura offre un solo avviso chiudibile e una diagnostica scaricabile. Il rapporto ammette soltanto versione, data, passaggi riconosciuti, categorie fisse degli endpoint, metodi, stato HTTP, flag e conteggio limitato degli eventi sulla sorgente; esclude SQL, ID, MID, nomi, payload, URL e risposte effettive. Chiudi resta rispettato durante l’attesa; una nuova procedura o il cambio contesto rimuovono la nota.

Verifica 1.1.31: 56 test unit passati e prova browser completa Automation Studio passata con fixture native simulate. Le regressioni includono Copy a icona, titolo e pulsante forniti, nuova query creata seguita dall’evento sul percorso originale e relativa rilettura, canonicalizzazione, annullamento/cambio attività/BU, client jQuery AMD separato, metadati assenti dalla cache, contenitori non Bootstrap, esclusione dei wizard Edit/Create/Script, download della diagnostica senza dati applicativi e chiusura persistente dell’avviso. La prova riproduceva i due mancati avvii prima delle correzioni e passa con il codice aggiornato. Sintassi di 48 file JavaScript e guida PDF aggiornate. Nessuna sessione Salesforce autenticata o creazione reale è stata usata; resta necessaria la conferma sul tenant. Nessun nuovo permesso e nessuna nuova prova dell’estensione caricata in Edge in questa revisione.

## Versione 1.1.30 — 28 ottobre 2026

Aggiunto automation/query-copy-navigation.js al bootstrap Automation Studio. Il componente riconosce Copy nativo dal dettaglio ActivityDetails di una Query Activity già caricata, il comando finale del modal e le risposte POST di creazione della collezione query o copy/clone della query sorgente. Usa solo un queryDefinitionId GUID valido e diverso dall’originale, nella BU e nel percorso iniziali. Dopo le callback native e la chiusura della procedura, sostituisce soltanto il GUID nel percorso esistente, nella stessa scheda. Non legge il SQL/payload e non modifica né ripete richieste. Il Copy SQL della toolbar rimane escluso.

Annulla, chiusura, Escape, cambio BU/percorso, risposte ambigue o non valide e scadenze invalidano la navigazione. L’intento dura dieci minuti; dopo il successo l’attesa della chiusura dura al massimo trenta secondi. Il controllo periodico si avvia soltanto dopo il completamento di una richiesta osservata con un risultato valido; nessun polling di rete.

Verifica 1.1.30: 56 test unit passati e nuova prova browser con bootstrap effettivo Automation Studio, jQuery e wizard simulato passata. Quattordici scenari coprono creazione/chiusura, singola apertura, payload e callback nativi invariati, save normale, clipboard Copy, annullamento, errore e riprova, ID originale/non valido, metodi e percorsi estranei, origine diversa, scadenza e risposte tardive dopo annullamento/Escape/cambio BU/navigazione, più endpoint copy esplicito. Controllate sintassi di 48 file JavaScript e guida PDF 1.1.30. Le prove non usano una sessione Salesforce autenticata né creano attività reali. Le varianti del DOM, degli endpoint o delle risposte non riconosciute mantengono il comportamento nativo; occorre confermare il flusso sul tenant. Nessun nuovo permesso e nessuna prova aggiuntiva di caricamento dell’estensione in Edge in questa revisione.

## Versione 1.1.29 — 28 ottobre 2026

Rimossi Tracking Test, Test History, la registrazione dei tentativi di invio e le anteprime generate dai log. Eliminati i due content script di navigazione Tracking dal manifest e i relativi file; rimossi i template della cronologia e della preview. Preview and Test conserva soltanto il toolbox Impostazioni SFMC per MID e caricamento della rubrica DE, con visibilità configurabile. Il reset dell’asset al cambio BU ora appartiene al bootstrap Content Builder.

La rubrica tester, i suggerimenti e la cartella DE recenti restano operativi. I recenti osservano le preview native riuscite; i vecchi log non vengono cancellati e possono ancora fornire riferimenti DE validi, senza generare nuovi log di invio. Il percorso nativo Salesforce di invio non viene modificato.

Verifica della 1.1.29: 56 test unit passati; prove browser dei sorgenti con Chromium su fixture Salesforce per rubrica, visibilità delle sole Impostazioni SFMC, DE recenti e Advanced passate. La prova con bootstrap completo verifica assenza dei controlli rimossi, conservazione dei log precedenti e un invio nativo simulato completato una sola volta senza scritture nello storico. Verificate sintassi di 46 file JavaScript e guida PDF aggiornata. Nessun invio reale e nessuna sessione Salesforce autenticata sono stati usati. Lo smoke test con estensione caricata in Edge è aggiornato ma non eseguito in questa revisione, poiché il browser richiesto non è disponibile.

Le sezioni successive descrivono anche l’originale e le versioni precedenti, comprese funzioni ora rimosse.

## 1. Che cosa c'è nella cartella

È già una vera estensione Chrome, chiamata **SFMC UI Fixer**, con Manifest V3, versione 1.0, e autore indicato nel package `Simone Luise`. Non è una Salesforce App e non richiede di installare un pacchetto nel tenant per il funzionamento previsto dal codice.

L'estensione aggiunge pulsanti, pannelli, stili e comportamenti alle pagine Marketing Cloud mentre lavori con la tua sessione già autenticata. Può anche inviare richieste alle API interne usate dall'interfaccia, per esempio per leggere una DE o inserire più record. Vale quindi il normale accesso Salesforce dell'utente: l'estensione non concede permessi aggiuntivi su altre BU.

L’autore della versione Multi BU preparata è **Francesco Trepiccioni**. La cartella `stable` è rimasta intatta. La versione modificata è in `sfmc-ui-fixer-multi-bu`. Il pacchetto installabile in modalità sviluppatore viene generato in `dist`.

## 2. Come funziona tecnicamente

Il percorso principale è questo:

```text
Pagina/iframe di Marketing Cloud
  → loader.js (content script Chrome, mondo isolato)
  → content.js (script nel contesto della pagina)
  → modulo del prodotto: Contact / Content / Automation / Journey / Query Studio
  → componenti, stili e template HTML

Script nella pagina
  ↔ messaggi window.postMessage
  ↔ loader.js
  ↔ background.js, service worker Chrome
  ↔ chrome.storage.local
```

`manifest.json` stabilisce domini, permessi e file iniziali. L'opzione `all_frames: true` consente l'esecuzione anche negli iframe, molto usati da Marketing Cloud. Non significa che tutti gli iframe espongano lo stesso contesto o che siano accessibili senza limiti.

`loader.js` crea la configurazione e inietta `content.js`. Fa da ponte per lo storage, con operazioni e contesti limitati, perché lo script nella pagina non può usare direttamente `chrome.*`. Alcune pagine, compreso il contenitore `/cloud/`, vengono ignorate: il lavoro avviene soprattutto nei frame dei singoli prodotti.

`content.js` crea l'oggetto globale `window.sfmcfix`, carica CSS/JS/HTML e sceglie il modulo in base all'URL. Installa intercettori jQuery sulle richieste AJAX: i moduli possono osservare risposte, modificare liste restituite o sostituire alcune risposte con dati locali. Le cartelle "Recently used" del selettore DE sono esempi di cartelle virtuali dell'interfaccia: non sono vere cartelle create nel tenant.

`background.js` legge e scrive lo storage dell'estensione. Serializza le modifiche, così due frame non si sovrascrivono facilmente durante un merge. Il clic sull'icona apre la pagina delle versioni SQL.

Nella nuova versione `context.js` viene inizializzato prima dei moduli: gestisce stack, MID, preferenze, cache separate e costruzione dei link. Il nuovo `contactbuilder/email-studio.js` osserva il dettaglio della DE e mantiene aggiornato il collegamento a Email Studio.

**Dipendenza fondamentale:** molte integrazioni usano API e selettori dell'interfaccia Salesforce, non un contratto API pubblico stabile. Una modifica a Marketing Cloud può richiedere manutenzione dell'estensione.

## 3. Funzioni realmente presenti nell'originale

### Contact Builder

| Funzione | Comportamento letto nel codice | Limiti |
| --- | --- | --- |
| Ricerca avanzata DE | Ricerca per nome con contiene, inizia con, finisce con; mostra nome e percorso | Legge la prima pagina, fino a 25 risultati. Non è una ricerca simultanea in tutte le BU |
| DE recenti | Memorizza le ultime DE visitate e offre un collegamento alla cartella | Circa 9 voci; nell'originale cache non separata per BU |
| Prima/ultima pagina | Aggiunge pulsanti per saltare agli estremi nella vista Record | Dipende dal pager corrente dell'interfaccia |
| Clone | Copia una riga visibile nel modulo di nuova riga | Usa il testo delle celle: HTML, date e formattazioni richiedono controllo prima del salvataggio; non duplica la definizione della DE |
| Multi Rows | Costruisce una tabella per inserire più righe; distingue chiavi e valori dalla definizione dei campi | Scrive dati reali dopo conferma; la validazione locale non sostituisce quella Salesforce |
| CSV | Esporta i record già caricati nella pagina corrente | Non esporta automaticamente l'intera DE; separatore `|` |
| Strumenti SMS | Evidenzia caratteri non GSM nel campo riconosciuto `sMS_TEXT`; collegamento a Messente | Riconoscimento del campo specifico; conteggio segmenti originale approssimativo |
| Campi più comodi | Rende più agevole l'editing di alcuni input | Dipende dai selettori dell'interfaccia |
| Validazione URL media | Nell'originale applicata a una sola DE con GUID fisso | Nella nuova versione applicata al campo `mediaURL` quando presente |

L'originale contiene anche componenti per una configurazione SMS aziendale, ma il caricamento del relativo pulsante è commentato e gli identificativi erano specifici del team. Non è una funzione generale attiva pronta per tutte le organizzazioni.

### Content Builder / Preview & Test

| Funzione | Comportamento letto nel codice | Limiti |
| --- | --- | --- |
| Autocompletamento tester | Cerca nome, cognome ed email in un elenco JSON statico; propone fino a 5 indirizzi | L'originale include contatti personali; nella nuova versione il file con i contatti è escluso e la rubrica è configurabile localmente per BU |
| Log test send | Registra localmente il payload del tentativo di invio, con data, destinatari, email e origine dati | Conservazione effettiva **60 giorni**, non 90 come scritto nel documento originale |
| Anteprima da log | Richiede una nuova preview usando email, DE e riga del test registrato | Non è una fotografia storica del rendering: asset e dati vengono riletti e possono essere cambiati |
| DE recenti per preview | Aggiunge cartelle virtuali per le DE utilizzate nell'email corrente e nei test recenti | Nell'originale legate alla cartella 782; nella nuova versione serve che la radice DE venga riconosciuta dalla risposta nativa |

Il log viene scritto **prima della risposta dell'invio**: documenta il tentativo e non certifica che l'email sia stata inviata o consegnata. Il tasto Remove è disabilitato nel template dei singoli log dell'originale.

### Automation Studio

- Mostra le ultime automation visitate, fino a circa 10.
- Aggiunge collegamenti per aprire un'attività dal canvas in una scheda separata, quando la risposta nativa contiene i relativi identificativi.
- Nella Query Activity aggiunge download JSON della configurazione, copia SQL e alternanza tra SQL scritto e SQL validato/generato da Marketing Cloud.
- Collega la DE target al dettaglio in Contact Builder.
- Salva uno snapshot locale della query/configurazione quando si entra in modifica tramite i pulsanti intercettati. Non è un audit completo di ogni modifica e non intercetta modifiche effettuate fuori dal percorso osservato, da altri utenti o via API.
- Il visualizzatore aperto dall'icona consente ricerca, lettura SQL, download ed eliminazione delle copie locali. Non ripristina automaticamente una Query Activity in Salesforce.

La nuova versione separa gli snapshot per stack/MID, mostra il contesto nel visualizzatore e aggiunge esportazione dello storico JSON. Le cancellazioni sono passate al service worker per non sovrascrivere versioni appena salvate da altri frame.

### Query Studio

- Comprimi/riapri la sidebar.
- Salva nuove query, aggiorna bozze, elenca e visualizza quelle salvate.
- Mantiene copie speciali dell'ultima query lanciata e dell'editor alla chiusura.
- Tenta di recuperare l'ultima query quando l'editor è vuoto.
- Copia la lista dei campi per preparare una SELECT; non genera una query completa con FROM e JOIN.
- Il pulsante originariamente chiamato `PKs` selezionava i campi **obbligatori**, non verificava le vere chiavi primarie. Nella nuova versione è denominato `Required`.

La nuova versione gestisce testo Unicode nel salvataggio locale. Il recupero alla chiusura resta dipendente dagli eventi del browser: non è un backup garantito contro crash o chiusura forzata.

### Journey Builder

Il collegamento preesistente apre un Journey referenziato da un elemento riconosciuto (`.ixn-collection-definition`) usando lo stack corrente.

Dalla versione 1.1.6 il modulo `journey/entry-de.js` legge esclusivamente i metadati della versione aperta: GET `/fuelapi/interaction/v1/interactions/<GUID>?extras=all&versionNumber=<n>` e, quando necessario, GET `/fuelapi/interaction/v1/eventDefinitions/<GUID>` oppure `key:<chiave>`. Richiede corrispondenza di ID e versione e una sola entry; accetta solo un GUID esplicito `dataExtensionId`/`dataExtensionID` nel trigger o nella definizione dell’evento. Non usa i dati delle attività successive, il nome della DE o l’External Key come se fossero il GUID.

Il comando **Apri Data Extension** viene aggiunto a elementi HTML con identificatori nativi corrispondenti al trigger (`data-key`, `data-activity-key`, `data-event-key`, riferimenti espliciti alla definizione evento o ID dell’elemento); sono supportati anche contenitori univoci di entry DE con tipo esplicito. Non viene costruito un overlay sul canvas SVG né aggiunta una barra generale. L’HTML effettivo dell’entry dell’utente non è ancora disponibile: il posizionamento resta da verificare/adattare nel tenant. Se il riquadro non è riconosciuto non compare alcun link.

Al cambio di route, versione o contesto il comando viene rimosso, la richiesta precedente annullata e le risposte tardive ignorate. Errori di accesso, eventi senza DE e più trigger non generano una destinazione di ripiego. Le letture non interrogano record delle DE e non modificano Journey o configurazioni.

## 4. Voci previste ma assenti o incomplete

Il file originale elenca come "upcoming", "to be analyzed" o commentati, fra gli altri:

- reinvio di un test dal log e indicazione log obsoleti;
- rinnovo automatico del token;
- trasferimento di record selezionati a un'altra DE;
- apertura DE da Query Studio in Contact Builder;
- collegamento DE da Email Studio a Contact Builder;
- apertura Journey dalle interazioni in Email Studio;
- impostazioni generali e Data Viewer.

Questa versione aggiunge preferenze essenziali per BU, l'esportazione dello storico SQL e la struttura del collegamento Contact Builder → Email Studio. Non presenta tutte le voci future come già implementate.

## 5. Perché l'originale non era universale per BU

**Stack e Business Unit sono cose diverse.** Il riferimento `s7` indica l'istanza/stack di Marketing Cloud, non il MID. Due BU possono condividere lo stesso stack e dominio; sostituire soltanto `s7` non separa i loro dati locali.

Ho trovato riferimenti operativi fissi allo stack s7 nei collegamenti Journey, Automation e Contact Builder, nella risoluzione delle cartelle e negli endpoint di inserimento righe. C'erano inoltre una cartella DE radice 782, GUID specifici per strumenti SMS/push e un elenco tester incorporato.

Cronologie DE, automation, test send e Query Studio usavano chiavi generiche nel `localStorage` del dominio. Le versioni SQL usavano uno spazio condiviso dell'estensione senza contesto BU esplicito.

Altri limiti riscontrati: il modulo DE non veniva caricato entrando direttamente sul dettaglio in alcune condizioni; il riconoscimento Journey era esclusivo di s7; i domini esposti dalle risorse del manifest non coincidevano interamente con quelli di caricamento; mancavano veri test; alcuni errori di ricerca lasciavano lo stato bloccato.

## 6. Che cosa cambia nella versione preparata

- Lo stack viene letto dal dominio corrente, dal referrer o dagli ancestor origin; non esiste un fallback silenzioso a s7.
- Il MID è letto solo da campi espliciti riconosciuti nel contesto nativo o nell'URL. Poiché non tutte le UI lo espongono nello stesso modo, esiste l'inserimento manuale per documento. Dopo un ricaricamento il MID manuale non viene riattivato automaticamente: un suggerimento validato in `sessionStorage` per scheda/origine permette di riconfermarlo. Il suggerimento non identifica la BU e non apre alcuna rubrica prima della conferma; un MID nativo riconosciuto ha sempre priorità. Non è stato verificato quali campi esponga il vostro tenant.
- Le cache sono prefissate con versione, stack e MID. Esempio concettuale: `SFMCFIX:v2:s42:123456:...`. L'isolamento evita di riusare cronologie di un'altra BU riconosciuta; non è una barriera di sicurezza contro altri script che girano nella stessa pagina.
- Se il contesto non è disponibile, le cronologie sono solo temporanee; niente archivio persistente in una BU "sconosciuta" condivisa. Il versionamento SQL chiede prima di impostare il MID.
- Le preferenze e i tester sono salvati nello storage Chrome per contesto; il collegamento Email Studio non richiede più un modello di URL. Il MID manuale non è un cambio BU Salesforce: devi aver selezionato la BU corretta nell'interfaccia.
- Gli endpoint di scrittura delle righe usano l'origine corrente e la DE aperta, con un controllo prima dell'inserimento multiplo.
- I link esistenti verso attività, Journey e Contact Builder usano lo stack corrente. Continuano a dipendere dalla sessione e dalla BU attiva di Salesforce; non effettuano un cambio account automatico.
- La ricerca gestisce caratteri speciali, cancellazione delle richieste superate ed errori HTTP. L'esportazione CSV gestisce virgolette, separatori e ritorni a capo.
- Il proxy fetch generico è stato rimosso nella 1.1.11. Il permesso `tabs` è stato rimosso: aprire la pagina interna non richiede il permesso di leggere le schede.
- Le anteprime email sono mostrate in un iframe sandbox. L'elenco personale dei tester non viene incluso nel pacchetto.

Questi cambiamenti rendono il codice **configurabile e collaudabile su BU e stack diversi**. Non costituiscono una certificazione di compatibilità con qualsiasi configurazione Salesforce.

## 7. La nuova funzione Contact Builder → Email Studio

Il comando compare dentro il contenitore del dettaglio DE, nelle schede Proprietà o Record. Legge il GUID dalla route Contact Builder `#admin/data-extension/<GUID>/...`. L'osservazione del DOM e il listener `hashchange` lo aggiornano quando Salesforce cambia pagina senza ricaricare il documento. Il GUID è riletto anche al clic, evitando un collegamento rimasto sulla DE precedente.

Il collegamento è automatico: lo stack deriva dal contesto corrente e il GUID dalla route Contact Builder. Non richiede un modello URL o l’inserimento manuale del MID. Dalla versione 1.1.5 MID e Tester BU si aprono dall’icona Impostazioni SFMC accanto a Test History, solo in Preview and Test. La barra flottante generale è stata rimossa dalle Data Extension e dagli altri moduli; nel Journey Builder e nei suoi frame i controlli restano esclusi. Il rilevamento del contesto continua a funzionare anche senza interfaccia flottante.

La rotta nativa è `Subscribers/Data_Extensions/<GUID>/edit`. È stata individuata nel codice Email Studio fornito per l’analisi: `js/router` inoltra `data_extensions` a `loadDE`, quindi a `loadExistingDE`; il ramo della UI moderna apre `de-pages` con `job: properties` e lo stesso identificativo, mentre quello legacy apre `ObjectDetails.aspx` con quel GUID. Il modello nativo carica i metadati da `internal/v1/customobjects/<GUID>`, coerentemente con il dettaglio di Contact Builder.

La shell può riportare il percorso al solo Subscribers durante l’avvio, scartando il dettaglio. Dalla versione 1.1.4 il link passa il GUID come parametro `sfmcfix_de` nel frammento della pagina Email. Uno script isolato a `document_start` lo conserva prima della normalizzazione del percorso, poi attende il documento C12 effettivamente caricato. Dalla versione 1.1.7 il documento può essere su `members.<stack>.exacttarget.com` oppure `mc.<stack>.exacttarget.com`, sempre sullo stesso stack: annuncia un `MessageChannel` alla shell, che verifica origine effettiva, finestra dell’iframe e percorso dichiarato prima di accettarne la porta. Richieste e risposte passano attraverso questa porta, legata al documento, anche se `iframe.src` conserva l’indirizzo precedente a SSO. La shell non invia più postMessage a un’origine ipotizzata dal src durante il caricamento. Uno script nel mondo principale del frame attende il router Backbone nativo e `_NavState`, quindi richiama la rotta del dettaglio e conferma che lo stato nativo contiene il GUID richiesto. Non esegue scritture sui dati della DE.

L’annuncio iniziale verifica origine e finestra; i messaggi sul canale dedicato verificano GUID e identificativo della richiesta. Annunci da finestre estranee o stack diversi vengono scartati. Le porte vengono chiuse al completamento o all’annullamento. Le richieste duplicate non provocano nuove navigazioni; l’attesa è limitata e si annulla se si lascia Email Studio. Le schede Email aperte senza il parametro dell’estensione mantengono il comportamento ordinario. Non servono nuovi permessi. L’apertura usa un normale link HTTPS con destinazione `_blank` e `noopener noreferrer`; il GUID viene ricalcolato al clic e prima della destinazione del pulsante centrale.

Il collegamento usa la sessione Email Studio corrente e non cambia automaticamente cliente o BU. Seleziona la BU corretta e riapri Contact Builder dopo un cambio di contesto. Per DE condivise, sincronizzate o di altri tipi speciali occorre verificare disponibilità e permessi nel tenant. La verifica locale del router non equivale a un collaudo autenticato su ogni tenant.

### Visibilità e tracking dei test dalla versione 1.1.6

La chiave generale `SFMCFIX---UI-PREFERENCES` in `chrome.storage.local` contiene `hidePreviewIcons`. La pagina dell’estensione la salva attraverso il service worker e i frame recepiscono gli aggiornamenti tramite il bridge esistente. Non dipende da stack/MID e non altera `SFMCFIX---SETTINGS-V2` o i log. Le icone possono essere riattivate dalla pagina dell’estensione anche quando entrambe sono nascoste.

Il nuovo collegamento accanto a Send Test usa il percorso Tracking fornito dall’utente con lo stack corrente e un marcatore nel frammento. Gli script dedicati conservano l’intento prima della normalizzazione della shell, usano lo stesso annuncio verificato e canale privato della navigazione DE, controllano l’identificativo della richiesta, attendono il menu nativo Tracking e cercano nei frame sotto `fraLeftNav` la voce nativa Test Send Emails, poi la cliccano. Non viene dedotto un category ID dal nome e non viene selezionata la cartella generica Sends. L’attesa è limitata; le normali pagine senza marcatore non vengono modificate. Il comando apre la cartella generale dei test e non identifica un singolo job.

Dalla versione 1.1.8 Tracking usa `_NavState.curNavItem` per riconoscere il menu selezionato: `sectionId` può legittimamente essere nullo dopo un clic nativo. Per cambiare sezione imposta `sectionId: Tracking`, lasciando a `navView._selectItem` e `uiView/legacyView` il caricamento della vista già presente. Non invoca `Backbone.history.navigate(..., {trigger:true})` sul percorso generale Tracking: il router nativo `switchPage` rimuove `currentView` prima di costruire la nuova vista e può rimuovere il contenitore di base.

Dopo il clic sulla cartella, l’apertura viene confermata solo quando `fraContent` ha un documento caricato, non vuoto e diverso dal documento precedente (oppure già intitolato Test Send Emails). Il controllo è strutturale e non legge i record dell’elenco. Le fasi comunicate alla shell e gli errori distinguono inizializzazione, cambio di menu, ricerca della cartella e caricamento del contenuto.

Dalla versione 1.1.9 l’URL iniziale di Tracking test usa `ks#Subscribers`, già impiegato dal collegamento DE funzionante; `sfmcfix_tracking=tests` mantiene separata la destinazione finale. Per un modello di stato esistente ma senza `curNavItem`, il codice verifica la presenza di `fraLeftNav` e della voce Tracking in `ET.Config.navData.entry`, quindi attiva una sola volta la selezione nativa, azzerando soltanto gli argomenti di navigazione transitori. Quando `sectionId` è già Tracking, riemette l’evento pubblico del modello perché il valore identico non genera un evento Backbone. Il listener nativo resta responsabile della scelta della voce; non vengono inventati modelli o identificativi.

In caso di errore la shell permette di scaricare `sfmc-tracking-diagnostica.json`. Il documento C12 riporta solo host/percorso senza query, stato del documento, presenza di stato/menu/frame, sezioni appartenenti a un elenco fisso e flag del tentativo di recupero. La shell aggiunge versione, data e presenza del canale nativo. Non vengono esportati campi arbitrari del modello, nomi di utenti, MID, record, token o contenuti delle risposte. Il file viene creato solo al clic dell’utente e non inviato automaticamente.

Dalla versione 1.1.10 il pulsante si chiama **Tracking Test**. La ricerca della cartella percorre soltanto i documenti accessibili sotto `fraLeftNav`, fino a tre livelli, senza richiedere `strCurSect` o il nome `fraTree`. Il titolo o un’intestazione/breadcrumb visibile Test Send Emails nel solo frame di contenuto permettono di riconoscere un elenco già aperto o aggiornato senza sostituire il documento. Non viene usato il testo della cartella nell’albero come conferma del contenuto.

Listener del modello nativo, eventi di caricamento e osservatori del DOM richiedono un controllo immediato e accorpato; un intervallo di 100 ms resta come ripiego per i cambiamenti delle variabili globali. Alla conclusione o all’annullamento vengono rimossi listener e osservatori. Ogni nuova fase riceve fino a 20 secondi, entro 60 secondi dall’inizio della richiesta; il limite della shell è 75 secondi, includendo il bootstrap.

Dopo un errore il documento osserva soltanto per altri 120 secondi, senza navigare o cliccare, e può comunicare un’apertura tardiva. La shell mantiene la porta privata per questa conferma e rimuove l’avviso appena arriva. **Chiudi** annulla i controlli e rimuove l’avviso; l’avviso scompare comunque dopo 30 secondi. Un cambio di modulo o la chiusura della pagina annullano anche l’osservazione tardiva.

## 8. Dove finiscono i dati

| Dati | Posizione nella nuova versione | Note |
| --- | --- | --- |
| DE recenti, automation, test send, query salvate | `localStorage` del modulo, separato per stack/MID | Non si sincronizzano automaticamente tra dispositivi o domini diversi |
| Cache quando manca il contesto | Memoria del documento | Si perde al ricaricamento |
| Preferenze e tester | `chrome.storage.local`, per stack/MID | Persistono al ricaricamento; il MID manuale va riconfermato per accedere alla stessa rubrica |
| Suggerimento del MID manuale | `sessionStorage` della pagina, per scheda/origine | Solo promemoria per la conferma; non attiva il contesto né assegna automaticamente i tester alla BU |
| Versioni Query Activity | `chrome.storage.local`, per stack/MID | Restano finché eliminate o rimossa l'estensione; esportabili JSON |
| Dati reali DE e asset | Salesforce | Le funzioni di scrittura modificano il tenant con la sessione dell'utente |

Non è presente un backend di telemetria dell’estensione. Dalla versione 1.1.11 il controllo SMS è interamente locale e il collegamento a Messente è rimosso. Le anteprime email bloccano le risorse esterne per impostazione predefinita e permettono le immagini HTTPS solo con un comando e una conferma espliciti. Le richieste operative ai dati rimangono sui moduli Salesforce della sessione corrente.

Il `localStorage` non equivale a un archivio protetto o a un backup centralizzato. Disinstallazione, pulizia dei dati browser, profili differenti e limiti di quota possono far perdere i salvataggi. I file JSON esportati possono contenere SQL, nomi di DE e configurazioni interne.

## 9. Installazione e distribuzione

Per provarla ora su Chrome o Microsoft Edge: estrai `dist/sfmc-ui-fixer-multi-bu-diagnostica.zip`, apri `chrome://extensions` in Chrome o `edge://extensions` in Edge, attiva Modalità sviluppatore e scegli Carica estensione non pacchettizzata (Chrome) o Carica decompressa (Edge). Seleziona la cartella estratta contenente `manifest.json`. Disabilita l'originale se era già installata, poi ricarica Marketing Cloud.

Per una distribuzione ordinaria con **Aggiungi a Chrome** serve il Chrome Web Store: account sviluppatore, scheda dell'estensione, descrizioni dei dati/permessi, materiali richiesti dallo store e revisione Google. Il pacchetto ZIP è il sorgente da caricare, non un'installazione automatica già pubblicata. In aziende con Chrome gestito l'amministratore può valutare le policy di distribuzione.

Questa distinzione è prevista dalla [documentazione ufficiale Chrome sulla distribuzione](https://developer.chrome.com/docs/extensions/how-to/distribute). L'installazione di sviluppo è descritta nel [tutorial ufficiale](https://developer.chrome.com/docs/extensions/get-started/tutorial/hello-world).

Per la distribuzione ordinaria su Microsoft Edge è disponibile Microsoft Edge Add-ons, con account sviluppatore e revisione dello store. Non è stata effettuata una pubblicazione su alcuno store né modificata la configurazione del browser dell’utente. Il pacchetto condiviso usa le API `chrome.*` supportate da entrambi i browser; non richiede un manifest Edge separato. I dati locali non si trasferiscono automaticamente fra browser o profili.

## 10. Verifiche eseguite e collaudo ancora necessario

Le verifiche locali del collegamento coprono URL su stack differenti, MID differenti o assente, vecchi modelli URL ignorati, aggiornamento del GUID durante la navigazione senza ricaricamento, apertura del collegamento, scomparsa tornando all’elenco e assenza di una destinazione con stack ignoto. Sono stati verificati anche sintassi JavaScript e integrità del pacchetto.

I controlli del router utilizzano il modulo nativo `js/router` fornito per l’analisi, con dipendenze e stato applicativo simulati: verificano che il GUID raggiunga Properties nella UI moderna e ObjectDetails nella UI legacy. Le prove con frame di origini diverse riproducono la normalizzazione del percorso esterno, il caricamento ritardato del modulo e del router, l’annullamento quando si cambia modulo, il rifiuto dei messaggi di conferma di origine errata e il timeout. Le prove nel browser usano pagine simulate. Non eseguono le API Salesforce né certificano l’apertura in una sessione autenticata; il collaudo reale resta necessario.

La rubrica mantiene il formato di archivio precedente: un array di triple Cognome/Nome/Email per stack e MID. L’editor a righe nella 1.1.11 ammette fino a 1000 tester per BU; controlla ogni email, mostra gli errori di salvataggio e chiude senza salvare se cambia contesto. Il limite di cinque riguarda soltanto i suggerimenti visibili della ricerca. Il menu e Test History seguono la presenza del pannello nativo Preview and Test; la visibilità si aggiorna anche durante la navigazione senza ricaricamento.

Le verifiche nel browser simulato coprono dieci tester aggiunti e salvati dall’editor, recupero dei contatti preesistenti, annullamento, email non valide, errore dello storage, rimozione di una riga, ricerca e selezione del decimo tester, menu con tastiera, assenza di sovrapposizioni con il footer, uscita da Preview and Test e finestra su schermi piccoli. I controlli della rubrica usano uno storage simulato persistente tra i documenti: verificano salvataggio e recupero dopo il ricaricamento, riconferma obbligatoria del MID manuale, annullamento, separazione di due BU, priorità del MID nativo, rifiuto di suggerimenti di stack diverso o malformati e funzionamento quando `sessionStorage` non è disponibile.

Le nuove prove coprono la scelta di visibilità nella pagina reale dell’estensione con API Chrome simulate, persistenza al ricaricamento, aggiornamento in più pagine, ripristino dopo errore e integrità della rubrica. Il tracking è provato con il router nativo fornito e una navigazione fra tre frame simulati su stack diversi, cartella mancante, timeout, annullamento e pagina senza marcatore. Le prove Journey simulano i metadati: GUID/versione/evento, cambio versione, risposta obsoleta, evento senza DE, più trigger, permessi negati e aggancio a identificatori HTML espliciti. Non certificano la struttura DOM o l’autenticazione effettiva del tenant.

La regressione 1.1.7 riproduce con il codice precedente il messaggio esatto di origine non corrispondente mostrato dall’utente. I nuovi controlli osservano anche gli errori console del browser e coprono iframe.src ancora su members con documento su mc, documento intermedio C12 prima di un secondo reindirizzamento, risposta ritardata e SSO senza aggiornamento del src. Le aperture DE e tracking devono completarsi senza l’errore di origine; un falso annuncio dalla shell non deve ricevere il GUID. Una prova esegue la shell in un mondo isolato del browser e il ricevitore nel mondo principale, anche con reindirizzamento su mc. Queste navigazioni sono simulate e non verificano la catena SSO autenticata del tenant.

La regressione 1.1.8 usa Backbone 0.9.10 e i moduli nativi router, navView, uiView e legacyView forniti per l’analisi; i dati di navigazione e i server restano simulati. Con il codice precedente riproduce la rimozione della vista di base, che i vecchi test non simulavano. Con il nuovo codice verifica menu e vista preservati, sectionId nullo, menu già su Tracking, modello e contenuto ritardati, etichette span, risposta vuota del contenuto, cartella mancante e annullamento. Una prova usa shell isolata e documento reindirizzato da members a mc. Le dipendenze della prova sono esterne al pacchetto e non aggiungono librerie all’estensione.

Le prove 1.1.9 riproducono il timeout con `curNavItem` nullo e verificano il recupero sia quando `sectionId` è diverso, sia quando è già Tracking, inclusi argomenti di navigazione iniziali ancora presenti. Verificano anche il link da Preview and Test con ingresso Subscribers e marcatore Tracking, il download reale del rapporto JSON in caso di modello assente e l’esclusione di valori fittizi di sessione/contatti dai dati esportati. Il bootstrap e i server del tenant restano simulati: il rapporto serve a rilevare lo stato effettivo se il problema persiste nella sessione autenticata.

Le prove 1.1.10 riproducono un avviso 1.1.9 rimasto visibile dopo l’apertura. Verificano la ricerca senza variabile di sezione, un nome diverso del frame albero, il breadcrumb legacy anche su stack s10, il riconoscimento senza clic dell’elenco ripristinato, un aggiornamento del contenuto nello stesso documento, l’apertura dopo un errore senza ulteriori clic e la rimozione manuale/automatica dell’avviso. Una prova disabilita tutti gli intervalli periodici dopo l’avvio del menu: l’inserimento della cartella e il successivo caricamento vengono gestiti dai soli eventi. Una seconda prova distribuisce 38 secondi su due fasi senza generare un errore anticipato. Il caricamento effettivo di Salesforce resta da misurare nel tenant.

Prima di distribuire al team, il collaudo sul tenant deve coprire:

1. Caricamento in Chrome senza errori e comportamento con la versione originale disabilitata.
2. Due BU sullo stesso stack: MID mostrato, passaggio tra BU, cronologie e tester distinti.
3. Se disponibile, uno stack diverso da s7 e più moduli con iframe diversi.
4. Ricerca DE con caratteri speciali e apertura cartella; verifica del limite 25 risultati.
5. DE Proprietà/Record, clonazione e inserimento multiplo su dati di prova; CSV con a capo e virgolette.
6. Un test send con esito positivo e uno fallito: il log deve restare inteso come tentativo.
7. Cartelle virtuali delle DE recenti nel vostro selettore Content Builder.
8. Una Query Activity aperta e modificata, storico e download; due schede contemporanee.
9. Query Studio con accenti/Unicode, recupero bozza e passaggio di contesto.
10. Apertura automatica in Email Studio senza configurazione: DE A e poi DE B senza ricaricare, confronto nome e GUID, altre BU e stack, eventuali DE condivise e sessione scaduta.

La compatibilità universale e il collegamento Email Studio non possono essere dichiarati verificati prima di queste prove. Il collaudo deve confermare la destinazione della DE e il contesto della sessione.

## 11. Manutenzione e distribuzione

L’estensione non richiede una build o dipendenze npm. Modifica i sorgenti, ricarica l’estensione dalla pagina Estensioni e aggiorna le pagine Marketing Cloud aperte. Il distribuibile aggiornato si trova in `dist/sfmc-ui-fixer-multi-bu-diagnostica.zip`, con `manifest.json` alla radice.

Il pacchetto caricato originariamente non includeva i file `tests/extension.test.cjs` e `scripts/package_extension.py` citati nella documentazione precedente: quei comandi non sono disponibili in questo checkout. I controlli descritti sopra sono stati eseguiti durante lo sviluppo. La guida di collaudo Markdown e PDF descrive le prove da eseguire sul tenant.


## Compatibilità Edge dalla versione 1.1.18

È stato caricato il pacchetto estratto sul browser ufficiale Microsoft Edge 155.0.4283.62 per Linux, con le API native dell’estensione: service worker, storage locale e di sessione con accesso protetto, identificativi documento nativi, consenso nel content script isolato, salvataggio e rilettura dei tester della singola BU, pagina interna delle impostazioni e notifiche dirette al documento. Sono riuscite sullo stesso Edge anche le verifiche browser della rubrica DE, del download CSV di 100.000 record e del refresh automatico del Run Log. Le pagine Salesforce della verifica sono simulate; non è una sessione autenticata nel tenant né una prova su ogni sistema operativo.

La verifica ripetibile è `tests/extension.browser.cjs`, con Playwright disponibile e Microsoft Edge installato. Per scegliere un eseguibile specifico imposta `SFMCFIX_CHROMIUM_PATH`; per un’installazione Playwright esterna al progetto imposta `SFMCFIX_PLAYWRIGHT_MODULE`. Per esempio: `SFMCFIX_CHROMIUM_PATH=/percorso/msedge node tests/extension.browser.cjs`. Il test usa un profilo temporaneo ed elimina soltanto quel profilo al termine. Se le policy impediscono le estensioni di sviluppo, la prova resta bloccata: il test non modifica le policy. Anche le verifiche browser CSV, sorgente tester e Run Log accettano lo stesso percorso del browser.


## Ricerca Content Builder dalla versione 1.1.19

Il campo di aggancio è l’input Search `input[type="search"].form-control.dropdown-toggle` fornito dall’utente. Viene aggiunto un solo pulsante Advanced, rimosso quando il campo scompare e tenuto fuori da editor e modali. Il pannello nativo dialog gestisce focus, Escape, paginazione e messaggi accessibili; testi di asset, chiavi e percorsi non diventano markup.

`contentbuilder/asset-search.js` effettua soltanto query di metadati sulla stessa origine: POST alla query asset e GET alle categorie. Il client Fuel, se presente, gestisce le intestazioni della sessione; il ripiego fetch è limitato alla stessa origine e non viene tentato per aggirare un errore del client nativo. Le query combinano filtri strutturati, proiettano pochi campi e non ereditano la cartella o il testo della ricerca nativa. Non vengono caricati HTML o thumbnail. Le cartelle sono una cache temporanea per contesto; ogni ricerca e pannello hanno controlli di annullamento e delle risposte obsolete. Il filtro cartella è esatto, mentre la ricerca predefinita riguarda tutta la libreria accessibile.

Le righe native sono individuate tramite `data-flow-id="cb:repeater:list:<ID>"`, come nell’HTML fornito. Apri riutilizza il nome cliccabile di una riga già caricata oppure il percorso interno degli asset; eventuali varianti osservate nel frame durante la navigazione nativa vengono riutilizzate in memoria per tipo. Il collegamento non dipende dalla barra URL della shell Marketing Cloud. Percorsi interni, DOM e autorizzazioni rimangono dipendenti dal tenant; l’apertura nel tenant autenticato non è stata verificata in questo ambiente.

`tests/asset-search.test.cjs` copre filtri globali, campi proiettati, client Fuel, permessi, paginazione delle cartelle, annullamento e cambi BU. `tests/asset-search.browser.cjs` copre campo Search e riga forniti, filtri, 51 risultati su due pagine, percorsi, apertura nativa e percorso interno, nomi contenenti markup, interruzione, errori e dialog su schermo stretto. È stato eseguito su Chromium e Microsoft Edge con risposte Salesforce simulate; `tests/extension.browser.cjs` verifica anche l’iniezione delle nuove risorse dal pacchetto realmente caricato in Edge.

## Sessione e ricerca Content Builder dalla versione 1.1.20

Il 403 segnalato nella ricerca non dimostra da solo un MID mancante: la query usa la sessione Salesforce, mentre il MID locale separa cache e preferenze. Nel bundle nativo fornito dall’utente, la collection `content/lib/data/core-collections/asset-c` usa `?scope=ours`, `useFuel2Token`, `x-fueldata-version: 1.1`, Content-Type `application/json;charset=utf-8;datekind=local`, operatore `contains` e `values` per `in`. Advanced ora riproduce quel contratto senza ereditare la cartella corrente. La risoluzione del client considera anche il modulo AMD `fuel-ajax` già inizializzato, preservando il proprietario del metodo. La sessione rimane affidata al client nativo o al fetch della stessa origine; un errore non passa a un altro client o host.

`components/native-session.js` precede `context.js` nel bootstrap. Legge il MID da `organization.id` di GET `/fuelapi/platform/v1/tokenContext` nella stessa origine, con limite di 1800 ms; non deriva un MID da enterprise ID, utente o proprietario dell’asset. Se la lettura riesce prevale sugli indizi dell’URL; la conferma di accesso allo storage locale resta nel mondo isolato. Una lettura fallita elimina il MID ottenuto in precedenza dalla sessione. Nei moduli che non espongono questo endpoint restano gli identificativi espliciti e il MID manuale già previsti. Non si riusa automaticamente un suggerimento manuale salvato.

Il contesto viene aggiornato all’avvio, all’apertura di Advanced o delle impostazioni tester, prima della ricerca, al ritorno nella scheda e ogni 15 secondi mentre è visibile e il MID è stato rilevato dalla sessione. I job di ricerca sono creati prima della verifica asincrona del contesto: chiusura, annullamento o cambio BU durante questa verifica impediscono di avviare una nuova query. Le risposte del contesto oltre il timeout non aggiornano il MID. Il rapporto scaricabile è una proiezione di campi tecnici: versione, data, presenza/provenienza del MID, percorsi API fissi, metodo/scope/trasporto/stato e soli nomi delle intestazioni standard. Esclude MID numerico, filtri, asset, contenuti, token e risposte del server.

Le verifiche aggiornate richiedono scope e intestazioni prima di restituire risultati, usano un contesto senza MID nell’URL, cambiano MID durante una query lenta e controllano il download JSON. `tests/native-session.test.cjs` controlla anche la proiezione del contesto, gli ID esclusi, il modulo AMD già definito, il rifiuto senza ripiego, la mancata riattivazione del vecchio suggerimento e l’annullamento durante una lettura lenta. Le prove su Chromium/Edge simulano le risposte Salesforce. Non è disponibile qui la sessione del tenant: il 403 reale potrebbe dipendere anche dalle sue autorizzazioni o da differenze degli endpoint interni; il rapporto serve a distinguere questi casi senza richiedere comandi in Console.


## Correzione del trasporto Advanced nella versione 1.1.21

La diagnostica ricevuta per la 1.1.20 indica source=session e midDetected=true, GET categorie con stato 200 e POST query con stato 403; entrambe le richieste usano transport=fetch. Questi dati confermano il rilevamento del MID e separano il fallimento della POST dalle letture GET, ma non distinguono da soli protezioni della richiesta e permessi dell’endpoint.

Il difetto nel resolver era la mancata considerazione di Backbone.ajax e jQuery.ajax quando non sono esposti Fuel.ajax o un export fuel-ajax richiamabile. Il codice nativo fornito usa la collection asset-c, derivata da content/common/base-C, che delega alla Collection Backbone: il percorso nativo attraversa Backbone.ajax e la jQuery configurata dall’app. Il fetch diretto della 1.1.20 saltava ajaxSetup, prefilter e beforeSend. La nuova risoluzione mantiene la precedenza Fuel/fuel-ajax, poi usa Backbone.ajax o jQuery.ajax, globali o già definiti nel loader AMD; non inizializza moduli non caricati. Il proprietario dei metodi viene preservato e useFuel2Token continua a essere passato al client. Non vengono copiate credenziali, lette intestazioni di altre richieste o aggiunti gestori per rinnovare token.

La query POST richiede ora un client AJAX: senza client restituisce un errore locale e registra transport=unavailable senza inviare la POST. Solo le GET mantengono il ripiego fetch. Non si ritenta un 403 attraverso un altro trasporto. Percorsi, query e permessi restano gli stessi; risultati e cache mantengono i controlli al cambio contesto.

La prova browser imposta una configurazione AJAX sintetica con ajaxSetup, beforeSend e prefilter. Il server simulato accetta le GET ma respinge con 403 una POST diretta fetch, anche con tutte le intestazioni standard della 1.1.20; accetta la stessa query quando arriva attraverso la configurazione dell’app. Il percorso completo verifica anche Fuel AMD, Backbone, jQuery, paginazione, annullamento, cambio BU, rapporto JSON e rifiuto nativo senza secondo tentativo. La prova del pacchetto realmente caricato in Edge richiede anch’essa beforeSend e prefilter. Le risposte Salesforce restano simulate: la correzione del trasporto è verificata, mentre la causa completa del 403 del tenant richiede la verifica nella sessione dell’utente.


## Apertura dei risultati Advanced dalla versione 1.1.22

La ricerca ora funziona nel tenant, ma il pulsante Apri chiudeva il pannello senza aprire l’asset. Il ripiego precedente assegnava hash come asset/ID/email: l’assegnazione non dimostrava che Content Builder avesse una rotta corrispondente né che ascoltasse hashchange. Il test precedente controllava il cambio dell’URL, non il caricamento dell’editor.

`contentbuilder/asset-navigation.js` usa la riga nativa con ID esatto quando presente. Negli altri casi risolve il Backbone globale o già inizializzato in AMD e confronta la destinazione con i suoi handler registrati. Una rotta con un solo argomento identificativo può essere ricostruita dal pattern statico; rotte osservate durante letture native vengono ricordate per tipo soltanto in memoria. Percorsi con comandi distruttivi, catch-all o argomenti aggiuntivi ambigui vengono esclusi. Viene chiamato history.navigate con trigger=true, oppure loadUrl quando il frammento è già quello richiesto; non viene assegnato un hash presunto.

Il listener dei metadati asset emette solo ID e typeId nel documento corrente. L’apertura attende quella conferma per l’asset richiesto e la BU iniziale. Per editor in cache, accetta il cambio di vista nativo solo se lastloadedasset contiene quello stesso ID e tipo. Il timeout di otto secondi o un comando non riconosciuto ripristinano lo stesso pannello con risultati e filtri; richiamare Advanced durante l’attesa annulla l’apertura. Il normale evento close rimuove il pannello, mentre la chiusura temporanea per azionare la UI nativa non lo distrugge. Gli observer e i listener temporanei vengono rimossi al completamento o all’annullamento.

La diagnostica aggiunge soltanto metodo, esito, presenza del router e fino a 20 pattern statici di rotte asset/content/email, di massimo 200 caratteri, con caratteri ammessi e numeri rimossi. Non esporta il frammento corrente, la destinazione effettiva, ID, nomi o risposte. `tests/asset-navigation.test.cjs` copre risoluzione, esclusioni, conferme errate, timeout e cambio BU. La prova browser usa Backbone 0.9.10 reale con pushState e hashChange=false, verifica il DOM dell’editor dopo una lettura dei metadati, un primo risultato fuori pagina senza percorso appreso, cache senza nuova GET e ripristino dopo handler assente o senza effetto. Le librerie Backbone e Underscore sono incluse con licenza MIT esclusivamente sotto tests/vendor; non vengono caricate dal pacchetto nell’app Salesforce. La prova Edge dell’estensione completa conferma anche la riga nativa e l’evento emesso dall’hook reale.

Non è disponibile qui una sessione Salesforce autenticata: DOM, percorsi e moduli differenti dal router riconosciuto restituiscono un messaggio con i risultati preservati e la diagnostica, invece di fingere un’apertura riuscita.


## Consenso locale di sessione dalla versione 1.1.23

Il popup ripetuto derivava dall’autorizzazione limitata al singolo documentId, che cambia quando Salesforce ricrea il frame Content Builder. Il worker conserva ora decisioni allowed/denied in chrome.storage.session, accessibile solo ai contesti fidati, indicizzate per origine esatta, ruolo e stack:MID. Ogni richiesta requestAccess da un nuovo documento riconosciuto crea una propria associazione pagina/documentId/tabId/scope con la scadenza assoluta della decisione iniziale (massimo 12 ore). Il ripristino non estende la scadenza. Un pending di due minuti limita i popup contemporanei; dopo l’abbandono un altro documento può richiedere la conferma. Il solo ponte della pagina continua ad accettare get/merge, non i comandi del consenso.

Il loader riutilizza il consenso dal worker prima di mostrare la conferma isolata; dopo LOCAL_ACCESS_REQUIRED rinnova una sola volta l’associazione e ripete l’operazione. Reset da pagina privata elimina le decisioni, invalida le associazioni e notifica anche i documenti precedentemente non autorizzati. Il contesto svuota la rubrica in memoria e la rilegge al successivo utilizzo esplicito; reset durante una richiesta invalida la risposta tardiva. La scadenza blocca anche le notifiche sensibili. Rubriche e copie SQL in chrome.storage.local non vengono cancellate.

Le verifiche unit coprono riuso tra documenti e schede, origine/modulo/BU separati, scadenza senza rinnovo implicito, diniego, pending abbandonato, reset riservato alla pagina privata, invalidazione delle richieste e rifiuto di comandi privilegiati dal ponte. La prova del pacchetto reale in Edge verifica nessun secondo popup dopo ricaricamento, uscita/rientro nel modulo e nuova scheda; una BU diversa richiede una conferma, il ritorno a una già autorizzata la riusa. Verifica inoltre il comando reset e la successiva rilettura dei tester conservati. Le pagine Salesforce restano simulate; la sessione autenticata dell’utente non è disponibile in questo ambiente.


## Banner delle automation recenti dalla versione 1.1.24

AutomationInstance.updateData richiama moveAutomationsToStorage sia alla ricezione dei metadati sia al cambio hash, quindi il passaggio tra Activity e Workflow generava più avvisi identici. È stata rimossa soltanto la notifica informativa da questo salvataggio automatico. Ordinamento, deduplicazione per ID, limite delle dieci voci e Clear restano invariati; le notifiche degli altri comandi non sono modificate.

Verifica mirata eseguita sul modulo Automation reale con DOM e risposte simulati: venti cambi Activity/Workflow e aggiornamenti ripetuti non generano banner, mentre aggiornamento del nome, ordinamento, deduplicazione e limite di dieci voci sono conservati. Superati anche i 41 controlli unit e il controllo sintattico dei JavaScript. Non è stata usata una sessione Salesforce autenticata.


## DE recenti nelle preview dalla versione 1.1.25

Il vecchio selettore ricavava le DE esclusivamente da testsendlogs, popolato prima di Send Test: una preview senza invio non alimentava i recenti. Inoltre il callback delle categorie aggiungeva le due cartelle su ogni pagina: la deduplicazione verificava soltanto gli items della singola risposta, non quelli già presenti nell’albero. Il limite globale veniva applicato prima della deduplicazione e anche l’elenco BU dipendeva dalla presenza di un asset corrente.

contentbuilder/recent-preview-des.js, inizializzato prima di previewandtest, osserva il completamento riuscito delle POST native guide/v1/emails/<emailID>/dataExtension/<GUID>/row/<row>/preview e delle varianti preview con dataSource strutturato. Non avvia nuove preview né invii. Conserva nel nuovo archivio del sito solo deId, emailID, assetId quando identificato e usedAt, per scope tramite api.local; massimo 200 coppie DE/email; riferimenti più vecchi di 60 giorni ignorati e scartati alla successiva scrittura. I riferimenti validi nei vecchi log vengono uniti e ordinati senza copiarne destinatari/record. Ogni cartella sceglie fino a otto GUID distinti dopo il filtro; quella globale non richiede currentasset. L’asset ID non viene confuso con il legacy email ID.

Le scorciatoie vengono inserite soltanto nella pagina 1 della radice DE rilevata, con ID confrontati come stringhe; count include le due voci su tutte le pagine, mentre page, pageSize e links rimangono nativi. Per il contenuto viene usata una GET metadati per GUID con client nativo e intestazioni della sessione; il ripiego è una GET fetch strettamente same-origin. Le letture contemporanee della stessa DE sono condivise e i metadati validi restano in cache per 30 secondi. Ogni richiesta è limitata a otto secondi, ha abort funzionante e non consegna dati di una BU/email precedente. DE 404/410 escluse; 403 e altre risposte non valide completano con errore. Il vecchio codice con fetch non controllato e callback abord è stato rimosso.

Verifiche: otto nuove prove unit per preview senza invio, cambio email, isolamento BU, paginazione, nomi distinti, recupero log, deduplicazione, dati malformati, client nativo, cache, errore/abort e risposte tardive. La prova browser usa il bootstrap reale Content Builder e gli hook jQuery con un selettore nativo simulato: tre pagine mantengono due scorciatoie e tutte le 60 cartelle originali, la preview senza Send Test sopravvive a cambio email e reload, la cartella per email resta distinta, i metadati richiedono la configurazione della sessione e il 403 completa senza blocco. Non sono salvati valori dei record o HTML e non viene inviata alcuna email. Le risposte Salesforce sono simulate: la sessione autenticata dell’utente non è disponibile.

L’intera suite conta 49 controlli unit superati. Superate anche le prove browser esistenti di ricerca Advanced/apertura nativa e sorgente tester condivisa con la nuova catena di caricamento.


## Recenti unificati e percorso tester dalla versione 1.1.26

Il selettore espone soltanto la cartella 999999990, DE recenti, con 20 GUID distinti della BU. Il vecchio identificativo viene riconosciuto per gestire richieste obsolete senza generare nuove cartelle. Il nuovo formato dello storage mantiene items e clearedAt nella stessa scrittura; i vecchi array sono compatibili. Clear scrive un archivio vuoto con marcatore crescente, esclude i vecchi log senza modificarli e invalida metadati/preview in corso. Le preview successive possono riaggiungere una DE. La deduplicazione in scrittura avviene ora per GUID. Il pulsante è aggiunto una sola volta all’header della cartella riconosciuta, con propagazione fermata per evitare un clic nativo involontario; il messaggio invita a riaprire l’elenco.

Le preferenze ammettono testerFolderPath, array di nomi relativo alla radice locale, limitato e validato dal worker, proiettato soltanto alla BU autorizzata. Il valore predefinito è [SFMC_UI_Fixer]. Il dialog accetta separatori /, → o > e un prefisso facoltativo Data Extensions; passare una bozza non cambia le preferenze. list normalizza il percorso e confronta l’intero fullPath: lunghezza, nomi, ID univoci, parentId consecutivi, root/category locale e cartella finale. Nessun nome viene usato come URL arbitrario. I record vengono richiesti solo dopo i controlli e lo schema. Cache e richieste pendenti sono indicizzate anche per percorso; il cambio di sorgente/percorso salvato invalida la cache. Il campo modificato blocca Salva sorgente finché Verifica e carica DE non riesce.

Le nuove regressioni verificano un solo shortcut su tre pagine, limite di 20 dopo deduplicazione, svuotamento per BU conservando byte per byte Test History, compatibilità dei vecchi array e risposte tardive. Le prove del percorso coprono sottocartelle valide, antenati errati, catene scollegate/shared, valori malformati, separazione della cache e validazione del worker senza alterare tester locali o altre BU. Le prove browser usano i moduli reali e risposte Salesforce simulate: verificano il pulsante Clear con reload, nuova preview dopo Clear, modifica/verifica/salvataggio del percorso e persistenza dopo reload, errore e annullamento. La sessione autenticata del tenant non è disponibile.


## Individuazione automatica della cartella tester dalla versione 1.1.27

Il resolver usa la ricerca di metadati esistente su customobjects/category/0 con retrievalType=1, name e includeFullPath, filtra Nome ed External Key tester_content_builder e richiede un risultato unico. Dal categoryId della DE legge fullPath e accetta la catena soltanto se la cartella finale si chiama SFMC_UI_Fixer sotto la radice locale, con ID univoci, parentId consecutivi, categoria e nomi validi e profondità limitata. I nomi degli antenati non richiedono configurazione. Schema e record sono letti solo dopo questi controlli; non viene enumerato inutilmente ogni ramo dell’albero.

Il dialog rimuove l’input del percorso e mostra quello rilevato. Salva sorgente conserva solo la scelta de/local. I valori testerFolderPath delle vecchie versioni restano nei dati e nel validatore del worker per compatibilità, ma non sono usati né come vincolo né come chiave della cache. La verifica esplicita invalida la cache e permette di individuare una cartella spostata. Restano timeout, cache di cinque minuti per BU, proiezione dei contatti e annullamento al cambio contesto.

Le regressioni verificano individuazione automatica sotto più antenati, cache, spostamento con refresh, vecchi path errati ignorati, catene scollegate/shared, cartella finale errata e DE ambigue senza lettura dei record. La prova browser esegue la catena reale con assenza del campo percorso, root iniziale, spostamento in sottocartella e nuovo percorso rilevato, persistenza della sorgente e vecchi path ignorati anche al reload. Salesforce è simulato: il tenant autenticato non è disponibile.


## Caricamento tester con un comando dalla versione 1.1.28

context.preferences.configureTesters gestisce una sola operazione concorrente, aggiorna contesto e autorizzazioni e richiama testerSource.activate. Il metodo forza una lettura fresca della DE, riusa i controlli di nome/percorso/schema/record e salva solo testerSource=de dopo una risposta valida nello stesso scope. Una DE vuota è ammessa; tutte le righe escluse bloccano l’attivazione con motivazioni aggregate. Le chiamate activate concorrenti condividono ricerca e salvataggio. Dopo il salvataggio viene ripristinata la cache validata, evitando una seconda lettura al primo suggerimento.

Il pulsante del menu resta nello stesso punto e passa da Carica tester dalla DE ad Aggiorna tester dalla DE. Stato busy, esito ed eventuale errore vengono mostrati nel menu, con link alla DE e percorso nel titolo del link. Il menu non viene chiuso all’avvio del comando. L’evento tester-loading svuota i suggerimenti precedenti; cambio BU e reset dei consensi eliminano l’esito e il collegamento. Il vecchio components/tester-editor.js e i relativi stili sono rimossi dal pacchetto. Nessun popup aggiuntivo per scelta della sorgente, inserimento righe o salvataggio; restano i consensi isolati per i dati locali quando necessari.

I tester locali preesistenti vengono conservati nello storage, senza aggiornamenti da questa operazione. Previewandtest richiede una sorgente DE attiva prima di cercare e non ripiega sulla rubrica locale. La prova browser con moduli reali verifica il clic singolo, assenza di editor/selettore, attivazione immediata, ricerca dalla cache senza nuove GET, rinnovo, record invalidi/403 e persistenza dopo reload. Le nuove prove unit verificano accorpamento di richieste, patch di sola sorgente, contatti locali conservati, mancato salvataggio in caso di errore/cambio BU e cache dopo attivazione. Le risposte Salesforce sono simulate e il tenant autenticato non è disponibile. Il test dell’estensione completa è stato adattato al nuovo percorso e resta eseguibile su un browser che consenta le estensioni di sviluppo.

Superati 56 controlli unit, la prova browser di attivazione in un clic (compresa migrazione con suggerimenti locali inattivi) e la regressione browser delle DE recenti. JavaScript e guida PDF verificati; il test di estensione completa è aggiornato ma non eseguito in questa revisione in assenza del browser di sviluppo Edge usato in precedenza.
