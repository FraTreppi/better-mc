# SFMC UI Fixer — Multi BU 1.1.38

**Autore della versione Multi BU: Francesco Trepiccioni.** Derivata da SFMC UI Fixer di Simone Luise.

[Scarica lo ZIP per Chrome e Microsoft Edge](https://github.com/FraTreppi/better-mc/raw/refs/heads/main/dist/sfmc-ui-fixer-multi-bu-diagnostica.zip)

La **[Guida utente](GUIDA_UTENTE.md)**, disponibile anche come **[PDF](GUIDA_UTENTE.pdf)**, descrive tutte le funzionalità e come usarle: installazione, configurazione delle BU, rubrica tester, cronologie, strumenti DE, Automation Studio, Query Studio e Journey Builder.

## Installazione e aggiornamento

Lo stesso ZIP funziona su **Google Chrome e Microsoft Edge basato su Chromium**. Estrailo in una cartella permanente, poi:

- **Edge:** apri `edge://extensions`, attiva **Modalità sviluppatore**, premi **Carica decompressa** e seleziona la cartella contenente `manifest.json`.
- **Chrome:** apri `chrome://extensions`, attiva **Modalità sviluppatore** e scegli **Carica estensione non pacchettizzata** sulla stessa cartella.

Usa un browser aggiornato; il requisito Chromium minimo è 111. Lo ZIP è per l’installazione manuale in modalità sviluppatore: non è una pubblicazione su Microsoft Edge Add-ons o Chrome Web Store.

La pubblicazione dello ZIP su GitHub non aggiorna una copia decompressa: **Ricarica** rilegge soltanto i file sul PC. Gli aggiornamenti automatici del browser richiedono una distribuzione tramite Chrome Web Store o Microsoft Edge Add-ons; questa versione non è pubblicata su questi store.

Per aggiornare, sostituisci i file nella stessa cartella e premi **Ricarica** sull’estensione. Poi aggiorna le schede Marketing Cloud. Non serve disinstallarla; mantenere la stessa installazione conserva i suoi salvataggi.

I salvataggi locali sono separati fra Chrome, Edge e i relativi profili: non vengono trasferiti automaticamente. In Edge verifica la BU rilevata e premi Carica tester dalla DE; la DE condivisa può fornire la stessa rubrica a entrambi i browser.

## Funzionalità

| Modulo | Strumenti |
| --- | --- |
| Contact Builder | Ricerca avanzata DE, visite recenti, prima/ultima pagina, CLONE, MULTI ROWS, CSV completo della DE con avanzamento e annullamento, analisi SMS locale, collegamento alla stessa DE in Email Studio. |
| Content Builder | Ricerca Advanced per nome, Customer Key o ID su tutte le cartelle della BU, filtri per tipo/cartella/date, risultati paginati e apertura dei contenuti. |
| Preview and Test | Tracking Test accanto a Send Test per aprire il tracking Salesforce dei test in una nuova scheda; caricamento e attivazione con un clic della rubrica DE tester_content_builder, fino a 1000 tester per BU, suggerimenti destinatari, cartella virtuale DE recenti con svuotamento. |
| Automation Studio | Apertura automatica della Query Activity appena copiata dal dettaglio dopo il completamento della procedura nativa; refresh automatico del Run Log ogni 5 secondi con pulsante ON/OFF, automation recenti, collegamenti alle attività e alla DE target, copia SQL, vista SQL validato, download JSON, copie locali prima della modifica. |
| Query Studio | Bozze, recupero dell’editor, elenco query, copia campi e campi obbligatori, pannelli comprimibili. |
| CloudPages | Pulsante accanto al nome per aprire l’editor in una nuova scheda, tramite selezione della pagina nell’elenco nativo. |
| Journey Builder | Collegamento ai Journey referenziati e alla DE dell’entry quando identificabile. |
| Pagina dell’estensione | Visibilità delle icone, consultazione ed esportazione delle versioni SQL, eliminazione delle copie locali, diagnostica Email Studio. |

L’icona Impostazioni SFMC compare solo in Preview and Test e può essere nascosta dalla pagina dell’estensione. I collegamenti usano la sessione e la BU attive di Salesforce: non cambiano cliente automaticamente.

## Rubrica DE condivisa

Crea in ogni BU la DE **tester_content_builder** dentro **SFMC_UI_Fixer**, anche in sottocartelle di Data Extensions, con Nome ed External Key `tester_content_builder` e campi `Nome` (Text), `Cognome` (Text), `Email` (EmailAddress, Primary Key). In **Preview and Test → Impostazioni SFMC**, premi **Carica tester dalla DE**: ricerca, verifica, lettura e attivazione avvengono in un’unica operazione, con esito e collegamento alla DE nel menu. **Aggiorna tester dalla DE** rilegge subito i contatti. I record vengono letti con la sessione corrente e non modificati. La [guida](GUIDA_UTENTE.md#rubrica-tester-bu) spiega schema, ricerca e aggiornamento dei contatti.

## Dove viene usata una DE

In **Contact Builder → Data Extensions**, apri una DE e premi **Dove viene usata** sopra il dettaglio. Il pannello mostra le query che leggono o scrivono la DE e le automation/step associati, nella **sola BU configurata**. SQL o collegamenti non risolti sono segnalati come analisi parziale.

Questa funzione richiede un **Installed Package Salesforce autorizzato in lettura** e il [componente locale Analisi DE](https://github.com/FraTreppi/better-mc/raw/refs/heads/main/dist/sfmc-de-usage-reader.zip), con Node 24.15 o successivo. Le credenziali Salesforce restano sul PC, fuori dall’estensione. [Configurazione e limiti](tools/de-usage/README.md). Le altre funzioni conservano il funzionamento della versione 1.1.37 caricata come base.

## Sicurezza e dati

La versione attuale restringe l’accesso ai dati locali al modulo, al documento e alla BU autorizzati. Per usare la rubrica o salvare copie SQL è richiesta una conferma locale con dominio, MID e stack. La scelta viene ricordata per dominio, modulo e BU durante la sessione del browser, fino a 12 ore: rientrare nello stesso modulo o aprire una nuova scheda non ripete la domanda. Dalla pagina dell’estensione puoi ripristinare le conferme senza cancellare i dati. Rifiutare non disabilita le altre funzioni.

Il proxy di rete generico è stato rimosso. Il controllo SMS è interamente locale. I CSV proteggono dai prefissi che i fogli di calcolo potrebbero interpretare come formule.

Queste misure riducono i rischi individuati e non costituiscono una garanzia assoluta. Le operazioni sui record usano la sessione Salesforce e possono modificare dati reali. Le copie locali e i file scaricati non sono cifrati dall’estensione.

Vedi **[Sicurezza e limiti](SICUREZZA.md)** per le protezioni e i rischi residui. La [documentazione tecnica](DOCUMENTATION.md) e la [cronologia](CHANGELOG.md) sono separate dalla guida utente.

La 1.1.37 ripristina Tracking Test accanto a Send Test, mantenendo rimossa Test History. Il collegamento apre la cartella generale Test Send Emails di Email Studio in una nuova scheda; la rubrica tester resta disponibile.
